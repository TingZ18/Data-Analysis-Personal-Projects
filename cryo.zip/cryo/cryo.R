# CRYO DATABASE
# 2024-04-17
# 20240408 data

rm(list=ls())
graphics.off()

setwd("C:/Users/60331706/Documents/cryo")
setwd("/Users/zhangting/Downloads/study & work/SLHD/cryo")

# read data ---------------------------
cryo <- read.csv("cryo_20240408.csv")
str(cryo)
names(cryo)
cryo <- cryo %>% rename(PATIENT.NAME=?..PATIENT.NAME)
nrow(cryo)   # 3923 pts

cryo$DOB.FIX <- as.Date(cryo$DOB.FIX, "%d/%m/%Y")
cryo$REFERRED.DATE <- as.Date(cryo$REFERRED.DATE, "%d/%m/%Y")
cryo$DATE.TRANSFERRED <- as.Date(cryo$DATE.TRANSFERRED, "%d/%m/%Y")
cryo$DATE.DECEASED <- as.Date(cryo$DATE.DECEASED, "%d/%m/%Y")
cryo$DATE.DISCARDED <- as.Date(cryo$DATE.DISCARDED, "%d/%m/%Y")

save(cryo,file="cryo.Rda")

library(dplyr)

load("cryo.Rda")

cryoadf <- cryo %>% 
  mutate(transfer = ifelse(!is.na(TRANSFER),1,0),
         deceased = ifelse(!is.na(DECEASED),1,0),
         discarded = ifelse(grepl("DISCARDED",cryo$DISCARDED),1,0)) %>%
  mutate(
    days.transferred = 
      floor(lubridate::time_length(difftime(DATE.TRANSFERRED, REFERRED.DATE), "days")),
    days.deceased =
      floor(lubridate::time_length(difftime(DATE.DECEASED, REFERRED.DATE), "days")),
    days.discarded =
      floor(lubridate::time_length(difftime(DATE.DISCARDED, REFERRED.DATE), "days"))
  ) %>%
  mutate(
    days.transferred = ifelse(is.na(days.transferred),
                              floor(lubridate::time_length(difftime(as.Date("2024-04-08"), REFERRED.DATE), "days")),
                              days.transferred),
    days.deceased = ifelse(is.na(days.deceased),
                              floor(lubridate::time_length(difftime(as.Date("2024-04-08"), REFERRED.DATE), "days")),
                              days.deceased),
    days.discarded = ifelse(is.na(days.discarded),
                              floor(lubridate::time_length(difftime(as.Date("2024-04-08"), REFERRED.DATE), "days")),
                              days.discarded)
  )

table(cryoadf$TRANSFER)
table(cryoadf$DECEASED)
table(cryoadf$DISCARDED)

table(cryoadf$transfer)
table(cryoadf$deceased)
table(cryoadf$discarded)

summary(cryoadf$days.transferred)
summary(cryoadf$days.deceased)
summary(cryoadf$days.discarded)

sum(is.na(cryoadf$days.transferred))
sum(is.na(cryoadf$days.deceased))
sum(is.na(cryoadf$days.discarded))

# --------------------------

# KM plot ------------------

library(ggsurvfit)

fit.transfer <- survfit(Surv(days.transferred/365.25,transfer) ~ 1, data = cryoadf)
fit.deceased <- survfit(Surv(days.deceased/365.25,deceased) ~ 1, data = cryoadf)
fit.discarded <- survfit(Surv(days.discarded/365.25,discarded) ~ 1, data = cryoadf)

library("survminer")
ggsurvplot(fit.transfer, censor.shape="|", censor.size = 4)

ggsurv3 <- function(fit,data,title) {
  ggsurvplot(fit, data, 
             break.time.by = 3, 
             cumevents = TRUE,
             xlab = "Time (years)",
             legend = "none",
             title = title,
             conf.int = TRUE, 
             risk.table = TRUE,
             tables.height = 0.15,
             tables.theme = theme_minimal(),
             risk.table.y.text = FALSE,
             legend.title="",
             ggtheme = theme_light(),
             size = 1,
             conf.int.style = "step",
             surv.median.line = "hv"
  ) 
}

ggsurv3(fit.transfer,cryoadf,"KM plot for Transfer (all patients)")
ggsurv3(fit.deceased,cryoadf,"KM plot for Deceased (all patients)")
ggsurv3(fit.discarded,cryoadf,"KM plot for Discarded (all patients)")

fit.transfer1 <- survfit(Surv(days.transferred/365.25,transfer) ~ 1, data = cryoadf[cryoadf$transfer==1,])
fit.deceased1 <- survfit(Surv(days.deceased/365.25,deceased) ~ 1, data = cryoadf[cryoadf$deceased==1,])
fit.discarded1 <- survfit(Surv(days.discarded/365.25,discarded) ~ 1, data = cryoadf[cryoadf$discarded==1,])

ggsurv3(fit.transfer1,cryoadf[cryoadf$transfer==1,],"KM plot for Transfer (transferred patients only)")
ggsurv3(fit.deceased1,cryoadf[cryoadf$deceased==1,],"KM plot for Deceased (deceased patients only)")
ggsurv3(fit.discarded1,cryoadf[cryoadf$discarded==1,],"KM plot for Discarded (discarded patients only)")

# discarded reasons strata
table(cryoadf$REASON.FOR.DISCARD,useNA = 'ifany')
cryoadf <- cryoadf %>%
  mutate(REASON.FOR.DISCARD = case_when(
    REASON.FOR.DISCARD == "PATIENT CONSENT " ~ "PATIENT CONSENT",
    REASON.FOR.DISCARD == "RECOVERY OF SPERMATOGENESIS " ~ "RECOVERY OF SPERMATOGENESIS",
    is.na(REASON.FOR.DISCARD) ~ NA,
    TRUE ~ REASON.FOR.DISCARD
  ),
  REASON.FOR.DISCARD.SIMPLE = case_when(
    REASON.FOR.DISCARD == "LTFU" | REASON.FOR.DISCARD == "DECEASED" |
      REASON.FOR.DISCARD == "UNKNOWN" ~ REASON.FOR.DISCARD,
    REASON.FOR.DISCARD == "RECOVERY OF SPERMATOGENESIS" |
      REASON.FOR.DISCARD == "RETURNED FERTILITY" ~ "RECOVERY",
    is.na(REASON.FOR.DISCARD) ~ NA,
    TRUE ~ "OTHER CLINICAL REASONS"
  ))
table(cryoadf$REASON.FOR.DISCARD,useNA = 'ifany')
table(cryoadf$REASON.FOR.DISCARD.SIMPLE,useNA = 'ifany')

save(cryoadf,file="cryoadf.Rda")

fit.discarded.reason <- survfit(Surv(days.discarded/365.25,discarded) ~ REASON.FOR.DISCARD, 
                         data = cryoadf)
ggsurvplot(fit.discarded.reason, data = cryoadf, 
           break.time.by = 3, 
           pval = TRUE,
           xlab = "Time (years)",
           title = "KM plot for Discarded (by reasons, discarded patients only)",
           conf.int = TRUE, 
           risk.table = TRUE,
           tables.height = 0.4,
           tables.theme = theme_minimal(),
           #risk.table.y.text = FALSE,
           legend.title="", # remove "Strata"
           legend = "none",
           legend.labs=c("CAFAT AUTHORISED","CLINIC MEETING","CONSENT EXPIRED",
                         "DECEASED","DOCTOR REQUEST","LTFU",
                         "NIL PARTNER CONTACT","NO LONGER REQUIRED",
                         "PATIENT CONSENT","PATIENT REQUEST",
                         "RECOVERY OF SPERMATOGENESIS","RETURNED FERTILITY",
                         "UNKNOWN"," VASECTOMY"),
           ggtheme = theme_light(),
           size = 1,
           conf.int.style = "step",
           surv.median.line = "hv"
)

fit.discarded.reason.simple <- survfit(Surv(days.discarded/365.25,discarded) ~ REASON.FOR.DISCARD.SIMPLE, 
                                data = cryoadf)
# names(fit.discarded.reason.simple$strata) <- gsub("REASON.FOR.DISCARD.SIMPLE=", "", names(fit.discarded.reason.simple$strata))
ggsurvplot(fit.discarded.reason.simple, data = cryoadf, 
           break.time.by = 3, 
           pval = TRUE,
           cumevents = TRUE,
           xlab = "Time (years)",
           title = "KM plot for Discarded (by simplified reasons, discarded patients only)",
           conf.int = TRUE, 
           risk.table = TRUE,
           tables.height = 0.2,
           tables.theme = theme_minimal(),
           #risk.table.y.text = FALSE,
           legend.title="", # remove "Strata"
           legend.labs = c("DECEASED","LTFU","OTHER","RECOVERY","UNKNOWN"),
           ggtheme = theme_light(),
           size = 1,
           conf.int.style = "step",
           surv.median.line = "hv"
)

# --------------------------

# 3 plots ------------------
# no function version
ggsurvplot(fit.transfer, data = cryoadf, 
           break.time.by = 3, 
           cumevents = TRUE,
           xlab = "Time (years)",
           legend = "none",
           title = "KM plot for Transfer",
           conf.int = TRUE, 
           risk.table = TRUE,
           tables.height = 0.15,
           tables.theme = theme_minimal(),
           risk.table.y.text = FALSE,
           legend.title="",
           ggtheme = theme_light(),
           size = 1,
           conf.int.style = "step",
           surv.median.line = "hv"
) 
ggsurvplot(fit.deceased, data = cryoadf, 
           break.time.by = 3, 
           cumevents = TRUE,
           xlab = "Time (years)",
           legend = "none",
           title = "KM plot for Deceased",
           conf.int = TRUE, 
           risk.table = TRUE,
           tables.height = 0.15,
           tables.theme = theme_minimal(),
           risk.table.y.text = FALSE,
           legend.title="",
           ggtheme = theme_light(),
           size = 1,
           conf.int.style = "step",
           surv.median.line = "hv"
)
ggsurvplot(fit.discarded, data = cryoadf, 
           break.time.by = 3, 
           cumevents = TRUE,
           xlab = "Time (years)",
           legend = "none",
           title = "KM plot for Discarded",
           conf.int = TRUE, 
           risk.table = TRUE,
           tables.height = 0.15,
           tables.theme = theme_minimal(),
           risk.table.y.text = FALSE,
           legend.title="",
           ggtheme = theme_light(),
           size = 1,
           conf.int.style = "step",
           surv.median.line = "hv"
)
# --------------------------

# cumulative incidence -----------
survfit2(Surv(days.transferred/365.25, transfer) ~ 1, cryoadf) %>%
    ggcuminc(outcome = "outcome", size = 1) +
    add_risktable() +
    scale_x_continuous(name = "Time (years)", breaks=seq(0,25,3)) +
    add_confidence_interval() + 
    theme(panel.grid.minor = 
            element_line(colour="grey", linewidth=0.25, linetype = 2),
          panel.grid.major = element_line(linewidth=0.75)) +
    scale_color_manual(values=c("#fC6666")) + 
    add_censor_mark()
# --------------------------

# data wrangling error ----------
# do not use factor as outcome variable as an error would occur in ggsurvplot()
# Error in data.frame(..., check.names = FALSE) : arguments imply differing number of rows
  mutate(
    transfer = factor(ifelse(!is.na(TRANSFER),"TRANSFERRED","CENSOR"),
                      levels=c("CENSOR","TRANSFERRED")),
    deceased = factor(ifelse(!is.na(DECEASED),"DECEASED","CENSOR"),
                      levels=c("CENSOR","DECEASED")),
    discarded = factor(ifelse(grepl("DISCARDED",cryo$DISCARDED),"DISCARDED","CENSOR"),
                       levels=c("CENSOR","DISCARDED"))) %>%
  mutate(days.transferred = 
           floor(lubridate::time_length(difftime(DATE.TRANSFERRED, REFERRED.DATE), "days")),
         days.deceased =
           floor(lubridate::time_length(difftime(DATE.DECEASED, REFERRED.DATE), "days")),
         days.discarded =
           floor(lubridate::time_length(difftime(DATE.DISCARDED, REFERRED.DATE), "days"))) 
mutate(
  transfer = factor(transfer, levels=c("0","1"),
                    labels=c("censor","outcome")),
  deceased = factor(deceased, levels=c("0","1"),
                    labels=c("censor","outcome")),
  discarded = factor(discarded, levels=c("0","1"),
                     labels=c("censor","outcome"))
) 
# --------------------------

# data for analysis --------

load("cryoadf.Rda")

cryoadf <- cryoadf %>%
  rename(age = AGE.at.COLLECTION,
         n_stored = No..COLLECTIONS.STORED,
         fu = F.U.VISIT,
         n_fu = No....F.U.VISITS,
         storage = In.Storage.vs.No.stored.material) %>%
  mutate(age = as.numeric(substring(age,1,2)),
         n_stored = as.numeric(gsub("\\ |\\*","",n_stored)),
         marriage = case_when(
           grepl("DIVORCED",AT.CRYO.M.S.D.O) ~ "Divorced",
           grepl("ENGAGED",AT.CRYO.M.S.D.O) ~ "Engaged",
           grepl("SEPARATED",AT.CRYO.M.S.D.O) ~ "Separated",
           grepl("S",AT.CRYO.M.S.D.O) ~ "Single",
           grepl("D",AT.CRYO.M.S.D.O) ~ "Defacto",
           grepl("M",AT.CRYO.M.S.D.O) ~ "Married",
           TRUE ~ NA
         ),
         fu = case_when(
           grepl("YES",fu) ~ "YES",
           grepl("NO",fu) ~ "NO",
           TRUE ~ NA
         ),
         n_fu = as.numeric(gsub("\\ |\\*","",n_fu)),
         sperm_seen = case_when(
           grepl("DID NOT COLLECT",SPERM.SEEN) ~ NA,
           grepl("NO",SPERM.SEEN) ~ "NO",
           grepl("YES",SPERM.SEEN) ~ "YES",
           TRUE ~ NA
         )) %>%
  mutate(marriage = factor(marriage, 
                           levels=c("Married","Defacto","Single","Engaged",
                                    "Divorced","Separated"))) %>%
  mutate(n_straws = as.numeric(gsub("\\ |\\*","",No..STRAWS))) %>%
  mutate(n_straws = ifelse(is.na(n_straws) & !is.na(No..STRAWS),0,n_straws))

# the relationship between yrs and dates not being logical
cryoadf1 <- cryoadf %>%
  mutate(yrs_stored = round(lubridate::time_length(
    difftime(coalesce(DATE.DISCARDED, DATE.TRANSFERRED, DATE.DECEASED,
                      as.Date("2024-04-08")), REFERRED.DATE), "years"),1)) %>%
  relocate(yrs_stored,.after=YRS.STORED)
cryoadf1 <- cryoadf %>%
  mutate(yrs_stored = ifelse(storage=="In storage",YRS.STORED,
                             round(lubridate::time_length(
                               difftime(DATE.DISCARDED,REFERRED.DATE), "years"),1))) %>%
  relocate(yrs_stored,.after=YRS.STORED)

cryoadf <- cryoadf %>% expss::apply_labels(age="Age",marriage="Marriage")
cryoadf <- cryoadf %>% distinct()

save(cryoadf,file="cryoadf.Rda")

# --------------------------

# table1 --------------
fac <- cryoadf %>%
  mutate(transfer = factor(transfer, levels=c("1","0"), 
                           labels=c("Transferred","Not Transferred")),
         deceased = factor(deceased, levels=c("1","0"),
                           labels=c("Deceased","Not Deceased")),
         discarded = factor(discarded, levels=c("1","0"),
                            labels=c("Discarded","Not Discarded")))
library(table1)
table1(~ age + n_stored + n_straws + marriage + fu + n_fu + sperm_seen + storage +
         AT.CRYO.CHILDREN.Y.N + AT.CRYO.No..OF.CHILDREN +
         YRS.STORED | transfer, 
       data=fac,
       caption="Transfer: cryo storage")

table1(~ DIAGNOSIS, data=cryoadf, title="Table2: Diagnosis list")
table1(~ HOSPITAL, data=cryoadf, title="Table3: Hospital list")
# --------------------------

# COX model ----------------
library(survival)
library(survminer)
fit <- coxph(Surv(days.transferred,transfer) ~ age + marriage, data = cryoadf[cryoadf$transfer==1,])
fit
ggforest(fit)
forestmodel::forest_model(fit)

library(finalfit)
library(berryFunctions)
dependent_transfer <- "Surv(days.transferred,transfer)"
explanatory <- c("age","marriage")
num_transfer <- c(389,205,78,87,12,5,2)
fhr_cryo <- function(dependent, num) {
  fhr <-
    cryoadf %>% finalfit(dependent, explanatory) %>%
    mutate(hr_uni_cha = substring(`HR (univariable)`, 1, 4),
           hr_uni = as.numeric(hr_uni_cha),
           lower_uni_cha = substring(`HR (univariable)`, 7, 10),
           lower_uni = as.numeric(lower_uni_cha),
           upper_uni_char = substring(`HR (univariable)`, 12, 15),
           upper_uni = as.numeric(upper_uni_char),
           hr_multi_cha = substring(`HR (multivariable)`, 1, 4),
           hr_multi = as.numeric(hr_multi_cha),
           lower_multi_cha = substring(`HR (multivariable)`, 7, 10),
           lower_multi = as.numeric(lower_multi_cha),
           upper_multi_cha = substring(`HR (multivariable)`, 12, 15),
           upper_multi = as.numeric(upper_multi_cha)) %>%
    mutate(variable = c("Age", "Marriage:Married","Marriage:Defacto","Marriage:Single",
                        "Marriage:Engaged","Marriage:Divorced","Marriage:Separated"),
           var = c("Age", "Marriage","","","","",""),
           cat = c("","Married","Defacto","Single",
                   "Engaged","Divorced","Separated")) %>%
    mutate(`HR (univariable)` = ifelse(
      `HR (univariable)` == "-", "reference", `HR (univariable)`),
      `HR (multivariable)` = ifelse(
        `HR (multivariable)` == "-", "reference", `HR (multivariable)`)) %>%
    mutate(num = num)
  
  fhr$variable <- factor(fhr$variable,levels = fhr$variable)
  
  hrtbl <- fhr %>% dplyr::select(variable, var, cat, num, 
                                 `HR (univariable)`, `HR (multivariable)`)
  
  uni <- fhr %>% dplyr::select(variable,  
                               hr_uni, lower_uni, upper_uni, `HR (univariable)`) %>%
    mutate(group = "univariable") %>%
    rename("HR" = `HR (univariable)`, hr=hr_uni, lower=lower_uni, upper=upper_uni)
  
  multi <- fhr %>% dplyr::select(variable, 
                                 hr_multi, lower_multi, upper_multi, `HR (multivariable)`) %>%
    mutate(group = "multivariable") %>%
    rename("HR" = `HR (multivariable)`, hr=hr_multi, lower=lower_multi, upper=upper_multi)
  
  fhr <- uni %>% rbind(multi)
  
  ggplot(fhr,aes(x = hr, y = variable,xmin = lower, xmax = upper, 
                 color = group, shape=group)) +
    geom_pointrange(position = position_dodge(width = 0.8)) +
    geom_vline(xintercept = 1, linetype = "dashed") +
    facet_wrap(~variable, ncol = 1, scales = "free_y") +
    labs(title = "Hazard ratio (95% CI, log scale)") +
    scale_x_log10(limits = c(0.1, 10), 
                  breaks = c(0.1, 0.25, 0.5, 1, 2, 4, 10), 
                  labels = c("0.1", "0.25", "0.5", "1", "2", "4", "10"), expand = c(0,0)) +
    guides(shape = guide_legend(reverse=TRUE), color = guide_legend(reverse=TRUE)) +
    theme(
      plot.title = element_text(size=13, hjust = 0.5, vjust = 0, face="bold"),
      strip.text = element_blank(), # Hide both x and y-axis labels in facet
      legend.title = element_blank(),
      legend.position = c(.95, .85),
      legend.justification = c("right", "top"),
      legend.box.just = "right",
      legend.margin = margin(3, 6, 6, 6),
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      axis.ticks.y = element_blank(),
      axis.text.y = element_blank()
    ) -> p
  
  new <- as.data.frame(
    matrix(
      c(NA,"Variable",NA,"N","HR (95% CI, p-value) univariable", 
        "HR (95% CI, p-value) multivariable"),nrow=1
    ))
  revhrtbl <- hrtbl %>% insertRows(1, new = new) 
  
  p_left <-
    ggplot(revhrtbl, aes(y = variable)) + 
    scale_y_discrete(limits = rev(revhrtbl$variable)) +
    geom_text(aes(x=0, label=var), hjust=0, fontface = "bold") +
    geom_text(aes(x=1, label=cat), hjust=0) +
    geom_text(aes(x=2.2, label=num), hjust=1, 
              fontface = ifelse(revhrtbl$num == "N", "bold", "plain")) +
    theme_void() +
    coord_cartesian(xlim=c(0,3))
  
  p_right <-
    revhrtbl  |>
    ggplot() +
    scale_y_discrete(limits = rev(revhrtbl$variable)) +
    geom_text(aes(x=0, y=variable, label=`HR (univariable)`), hjust=0.5, 
              fontface = ifelse(
                revhrtbl$`HR (univariable)` == "HR (95% CI, p-value) univariable",
                "bold", "plain"),
              color = ifelse(
                revhrtbl$`HR (univariable)` == "HR (95% CI, p-value) univariable", 
                "black","#00BFC4")) +
    theme_void() 
  
  p_last <-
    revhrtbl  |>
    ggplot() +
    scale_y_discrete(limits = rev(revhrtbl$variable)) +
    geom_text(aes(x=0, y=variable, label=`HR (multivariable)`), hjust=0.5, 
              color = ifelse(
                revhrtbl$`HR (univariable)` == "HR (95% CI, p-value) univariable", 
                "black", "#F8766D"),
              fontface = ifelse(
                revhrtbl$`HR (univariable)` == "HR (95% CI, p-value) univariable", 
                "bold", "plain")) +
    theme_void() 
  
  layout <- c(
    area(t = 0, l = 1, b = 30, r = 4),
    area(t = 4, l = 4, b = 30, r = 6),
    area(t = 0, l = 6, b = 30, r = 9),
    area(t = 0, l = 9, b = 30, r = 10)
  )
  
  p_left + p + p_right + p_last + plot_layout(design = layout)
  
}

fhr_cryo(dependent_transfer,num_transfer)

# --------------------------

