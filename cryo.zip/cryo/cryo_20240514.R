# CRYO DATABASE
# 2024-05-06
# 20240506 data

rm(list=ls())
graphics.off()

setwd("C:/Users/60331706/Documents/cryo")
setwd("/Users/zhangting/Downloads/study & work/SLHD/cryo")

library(dplyr)
library(table1)
library(lubridate)
library(expss)

# read data ---------------------------
cryo <- read.csv("cryo_20240506.csv", na.strings = c(""))
str(cryo)
names(cryo)
cryo <- cryo %>% rename(ID = ?..ID)
nrow(cryo)   # 3923 pts

cryo$DOB.FIX <- as.Date(cryo$DOB.FIX, "%d/%m/%Y")
cryo$REFERRED.DATE <- as.Date(cryo$REFERRED.DATE, "%d/%m/%Y")
cryo$DATE.TRANSFERRED <- as.Date(cryo$DATE.TRANSFERRED, "%d/%m/%Y")
cryo$DATE.DECEASED <- as.Date(cryo$DATE.DECEASED, "%d/%m/%Y")
cryo$DATE.DISCARDED <- as.Date(cryo$DATE.DISCARDED, "%d/%m/%Y")

save(cryo,file="cryo.Rda")

# ---------------------------

# tidy data ---------------------------

load("cryo.Rda")

table(cryo$TRANSFER)
table(cryo$DECEASED)
table(cryo$DISCARDED)
table(cryo$Diagnosis.Code, useNA = 'ifany')
# 1=Seminoma, 2=Teratoma, 3= Hodgkins disease, 4=non-Hodgkins lymphoma, 
# 5= Leukemia, 6= Sarcoma, 7=Other cancers
# 8=non-Cancer, 9=Myeloma, 10= Marrow dysplasias

cryoadf <- cryo %>%
  mutate(Transfer = ifelse(!is.na(TRANSFER), 1, 0),
         Deceased = ifelse(!is.na(DECEASED), 1, 0),
         Discarded = ifelse(grepl("DISCARDED", DISCARDED), 1, 0)) %>%
  mutate(
    days.transferred = 
      floor(lubridate::time_length(difftime(DATE.TRANSFERRED, REFERRED.DATE), "days")),
    days.deceased =
      floor(lubridate::time_length(difftime(DATE.DECEASED, REFERRED.DATE), "days")),
    days.discarded =
      floor(lubridate::time_length(difftime(DATE.DISCARDED, REFERRED.DATE), "days"))
  ) %>% # days for missing DATE.TRANSFERRED will be NA, would be removed in KM plot
  mutate(Diagnosis = factor(Diagnosis.Code, levels=1:10, 
                            labels=c("Seminoma", "Teratoma", "Hodgkins disease", 
                                     "non-Hodgkins lymphoma", "Leukemia", "Sarcoma", 
                                     "Other cancers", "non-Cancer", "Myeloma", 
                                     "Marrow dysplasias")))

table(cryoadf$Transfer,useNA = 'ifany')
table(cryoadf$Deceased,useNA = 'ifany')
table(cryoadf$Discarded,useNA = 'ifany')
table(cryoadf$Diagnosis, useNA = 'ifany')

summary(cryoadf$days.transferred)
summary(cryoadf$days.deceased)
summary(cryoadf$days.discarded)

# --------------------------

# KM plot ------------------

library(ggsurvfit)

fit.transfer <- survfit(Surv(days.transferred/365.25,Transfer) ~ 1, data = cryoadf)
fit.deceased <- survfit(Surv(days.deceased/365.25,Deceased) ~ 1, data = cryoadf)
fit.discarded <- survfit(Surv(days.discarded/365.25,Discarded) ~ 1, data = cryoadf)

library("survminer")

ggsurv3 <- function(fit,data,title) {
  ggsurvplot(fit, data, 
             break.time.by = 3, 
             cumevents = TRUE,
             xlab = "Time (years)",
             legend = "none",
             title = title,
             conf.int = TRUE, 
             risk.table = TRUE,
             tables.height = 0.15,
             tables.theme = theme_minimal(),
             risk.table.y.text = FALSE,
             legend.title="",
             ggtheme = theme_light(),
             size = 1,
             conf.int.style = "step",
             surv.median.line = "hv"
  ) 
}

ggsurv3(fit.transfer,cryoadf,"KM plot for Transfer")
ggsurv3(fit.deceased,cryoadf,"KM plot for Deceased")
ggsurv3(fit.discarded,cryoadf,"KM plot for Discarded")

fit.transfer <- survfit(Surv(days.transferred/365.25,Transfer) ~ Diagnosis_updt, data = cryoadf)
fit.deceased <- survfit(Surv(days.deceased/365.25,Deceased) ~ Diagnosis, data = cryoadf)
fit.discarded <- survfit(Surv(days.discarded/365.25,Discarded) ~ Diagnosis, data = cryoadf)

ggsurv3.Dia <- function(fit,data,title) {
  ggsurvplot(fit, data, 
             break.time.by = 3, 
             #pval = TRUE,
             #cumevents = TRUE,
             xlab = "Time (years)",
             # legend = "none",
             title = title,
             #conf.int = TRUE, 
             #conf.int.style = "step",
             #surv.median.line = "hv",
             #risk.table = TRUE,
             #tables.height = 0.15,
             #tables.theme = theme_minimal(),
             #risk.table.y.text = FALSE,
             legend.title="",
             legend.labs = c("Seminoma", "Teratoma", "Hodgkins disease", 
                             "non-Hodgkins lymphoma", "Leukemia", "Sarcoma", 
                             "Other cancers", "non-Cancer", "Myeloma", 
                             "Marrow dysplasias"),
             ggtheme = theme_light(),
             size = 1
  ) 
}

ggsurv3.Dia(fit.transfer,cryoadf,"KM plot for Transfer")
ggsurv3.Dia(fit.deceased,cryoadf,"KM plot for Deceased")
ggsurv3.Dia(fit.discarded,cryoadf,"KM plot for Discarded")

# --------------------------

# table1 --------------
fac <- cryoadf %>%
  mutate(transfer = factor(Transfer, levels=c("1","0"), 
                           labels=c("Transferred","Not Transferred")),
         deceased = factor(Deceased, levels=c("1","0"),
                           labels=c("Deceased","Not Deceased")),
         discarded = factor(Discarded, levels=c("1","0"),
                            labels=c("Discarded","Not Discarded"))) %>%
  expss::apply_labels(transfer = "Transfer",
                      deceased = "Deceased",
                      discarded = "Discarded")
library(table1)
table1(~ transfer, 
       data=fac,
       caption="Transfer: cryo storage")
table1(~ Diagnosis | transfer, 
       data=fac,
       overall=c(left="Total"),
       caption="Diagnosis category")

pvalue <- function(x, ...) {
  # Construct vectors of data y, and groups (strata) g
  y <- unlist(x)
  g <- factor(rep(1:length(x), times=sapply(x, length)))
  if (is.numeric(y)) {
    # For numeric variables, perform a standard 2-sample t-test
    p <- t.test(y ~ g)$p.value
  } else {
    # For categorical variables, perform a chi-squared test of independence
    p <- chisq.test(table(y, g))$p.value
  }
  # Format the p-value, using an HTML entity for the less-than sign.
  # The initial empty string places the output on the line below the variable label.
  c("", sub("<", "&lt;", format.pval(p, digits=3, eps=0.001)))
}
table1(~ Transfer + Deceased + Discarded | Diagnosis, 
       data=fac[!is.na(fac$Diagnosis),],
       topclass="Rtable1-grid Rtable1-shade Rtable1-times",
       render="FREQ (PCT%)",
       overall = F,
       extra.col=list(`P-value`=pvalue),
       caption="Diagnosis category") 
# --------------------------

# data update: 20240513 ----------

load("cryo.Rda")

updt <- read.csv("cryoupdate_20240513.csv", na.strings = c("",NA))
updt <- updt %>% rename(ID = ?..ID) %>%
  select(-starts_with("X")) %>% filter(!is.na(ID)) %>%
  rename(Diagnosis.Code_updt = Diagnosis.Code) %>%
  select(ID, Diagnosis.Code_updt)

cryoadf <- cryoadf %>% left_join(updt, by="ID") %>%
  mutate(Diagnosis_updt = factor(Diagnosis.Code_updt, levels=1:14, 
                            labels=c("Seminoma", "Teratoma", "Hodgkins disease", 
                                     "non-Hodgkins lymphoma", "Leukemia", "Sarcoma", 
                                     "Other cancers", "non-Cancer", "Myeloma", 
                                     "Marrow dysplasias","Melanoma","Colorectal cancer",
                                     "Brain cancer","Prostate cancer")))

cryoadf <- cryoadf %>%
  #rename(storage = In.Storage.vs.No.stored.material) %>%
  mutate(age = floor(lubridate::interval(DOB.FIX, REFERRED.DATE) / lubridate::years(1)),
         n_stored = as.numeric(gsub("\\ |\\*","",No..COLLECTIONS.STORED)),
         marriage = case_when(
           grepl("DIVORCED",AT.CRYO.M.S.D.O) ~ "Divorced",
           grepl("ENGAGED",AT.CRYO.M.S.D.O) ~ "Engaged",
           grepl("SEPARATED",AT.CRYO.M.S.D.O) ~ "Separated",
           grepl("S",AT.CRYO.M.S.D.O) ~ "Single",
           grepl("D",AT.CRYO.M.S.D.O) ~ "Defacto",
           grepl("M",AT.CRYO.M.S.D.O) ~ "Married",
           TRUE ~ NA
         ),
         fu = case_when(
           grepl("YES",F.U.VISIT) ~ "YES",
           grepl("NO",F.U.VISIT) ~ "NO",
           TRUE ~ NA
         ),
         n_fu = as.numeric(gsub("\\ |\\*","",No....F.U.VISITS)),
         sperm_seen = case_when(
           grepl("DID NOT COLLECT",SPERM.SEEN) ~ NA,
           grepl("NO",SPERM.SEEN) ~ "NO",
           grepl("YES",SPERM.SEEN) ~ "YES",
           TRUE ~ NA
         )) %>%
  mutate(n_straws = as.numeric(gsub("\\ |\\*","",No..STRAWS))) %>%
  mutate(n_straws = ifelse(is.na(n_straws) & !is.na(No..STRAWS),0,n_straws)) %>%
  mutate(marriage = factor(marriage, 
                           levels=c("Married","Defacto","Single","Engaged",
                                    "Divorced","Separated"))) %>%
  # impute age and dates
  mutate(age = ifelse(is.na(age), as.numeric(AGE.at.COLLECTION), age),
         DOB.FIX = as.Date(ifelse(is.na(DOB.FIX), REFERRED.DATE - years(age), DOB.FIX), origin="1970-01-01"),
         REFERRED.DATE = as.Date(ifelse(is.na(REFERRED.DATE), DOB.FIX + years(age), REFERRED.DATE), origin="1970-01-01")) %>%
  mutate(age = ifelse(age == -3, 27, age),
         DOB.FIX = as.Date(ifelse(ID==2543, DOB.FIX - years(30), DOB.FIX), origin="1970-01-01")) %>%
  # impute yrs.stored
  mutate(yrs_stored = as.numeric(YRS.STORED)) %>%
  mutate(yrs_stored = ifelse(yrs_stored > 1000, NA, yrs_stored)) %>%
  mutate(yrs_stored = ifelse(is.na(yrs_stored),
                             ifelse(storage == "No stored material", 
                                    round(interval(REFERRED.DATE, DATE.DISCARDED) / years(1), 1),
                                    round(interval(REFERRED.DATE, as.Date("2024-04-08", origin="1970-01-01")) / years(1), 1)),
                             yrs_stored)) %>%
  mutate(yrs_stored = ifelse(is.na(yrs_stored) & !is.na(YRS.STORED),
                             as.numeric(gsub("<","",YRS.STORED)) - 0.5,
                             yrs_stored))
                             
# the relationship between yrs and dates not being logical
yrs <- cryoadf %>%
  mutate(yrs_stored = round(lubridate::time_length(
    difftime(coalesce(DATE.DISCARDED, DATE.TRANSFERRED, DATE.DECEASED,
                      as.Date("2024-04-08")), REFERRED.DATE), "years"),1)) %>%
  relocate(yrs_stored,.after=YRS.STORED) %>%
  mutate(DATA.DATE=as.Date("2024-04-08", original="1970-01-01")) %>%
  select(ID, REFERRED.DATE, storage, DATE.DISCARDED, DATE.TRANSFERRED, DATE.DECEASED, DATA.DATE, YRS.STORED, yrs_stored)
yrs1 <- cryoadf %>%
  mutate(yrs_stored = ifelse(storage=="In storage",YRS.STORED,
                             round(lubridate::time_length(
                               difftime(DATE.DISCARDED,REFERRED.DATE), "years"),1))) %>%
  relocate(yrs_stored,.after=YRS.STORED) %>%
  mutate(DATA.DATE=as.Date("2024-04-08", original="1970-01-01")) %>%
  select(ID, REFERRED.DATE, storage, DATE.DISCARDED, DATE.TRANSFERRED, DATE.DECEASED, DATA.DATE, YRS.STORED, yrs_stored)

cryoadf <- cryoadf %>% 
  expss::apply_labels(age = "Age",
                      n_stored = "No. stored",
                      marriage = "Marriage",
                      fu = "Follow up",
                      n_fu = "No. follow up",
                      storage = "Storage",
                      sperm_seen = "Sperm seen",
                      n_straws = "No. straws",
                      yrs_stored = "Years stored",
                      Diagnosis_updt = "Diagnosis")

fac <- cryoadf %>%
  mutate(transfer = factor(Transfer, levels=c("1","0"), 
                           labels=c("Transferred","Not Transferred")),
         deceased = factor(Deceased, levels=c("1","0"),
                           labels=c("Deceased","Not Deceased")),
         discarded = factor(Discarded, levels=c("1","0"),
                            labels=c("Discarded","Not Discarded"))) %>%
  expss::apply_labels(transfer = "Transfer",
                      deceased = "Deceased",
                      discarded = "Discarded") %>%
  select(ID, Diagnosis_updt:discarded, storage)

# --------------------------

save(cryo, cryoadf, fac, file="cryo.Rda")

