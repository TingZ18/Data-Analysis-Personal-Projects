# CRYO DATABASE
# 2024-06-05
# 20240408 data, 20240506 update

rm(list=ls())
graphics.off()

setwd("C:/Users/60331706/Documents/cryo")
setwd("/Users/zhangting/Downloads/study & work/SLHD/cryo")

library(dplyr)
library(table1)
library(lubridate)
library(expss)
library(survival)
library(survminer)
library(gtsummary)
library(gt)

load("cryo.Rda")
# ---------------------------

# read data ---------------------------
cryo <- read.csv("cryo_20240506.csv", na.strings = c(""))
str(cryo)
names(cryo)
cryo <- cryo %>% rename(ID = ?..ID)
nrow(cryo)   # 3923 pts

cryo$DOB.FIX <- as.Date(cryo$DOB.FIX, "%d/%m/%Y")
cryo$REFERRED.DATE <- as.Date(cryo$REFERRED.DATE, "%d/%m/%Y")
cryo$DATE.TRANSFERRED <- as.Date(cryo$DATE.TRANSFERRED, "%d/%m/%Y")
cryo$DATE.DECEASED <- as.Date(cryo$DATE.DECEASED, "%d/%m/%Y")
cryo$DATE.DISCARDED <- as.Date(cryo$DATE.DISCARDED, "%d/%m/%Y")

save(cryo,file="cryo.Rda")

# ---------------------------

# tidy data ---------------------------

table(cryo$TRANSFER)
table(cryo$DECEASED)
table(cryo$DISCARDED)
table(cryo$Diagnosis.Code, useNA = 'ifany')
# 1=Seminoma, 2=Teratoma, 3= Hodgkins disease, 4=non-Hodgkins lymphoma, 
# 5= Leukemia, 6= Sarcoma, 7=Other cancers
# 8=non-Cancer, 9=Myeloma, 10= Marrow dysplasias

cryoadf <- cryo %>%
  mutate(Transfer = ifelse(!is.na(TRANSFER), 1, 0),
         Deceased = ifelse(!is.na(DECEASED), 1, 0),
         Discarded = ifelse(grepl("DISCARDED", DISCARDED), 1, 0)) %>%
  mutate(
    days.transferred = 
      floor(lubridate::time_length(difftime(DATE.TRANSFERRED, REFERRED.DATE), "days")),
    days.deceased =
      floor(lubridate::time_length(difftime(DATE.DECEASED, REFERRED.DATE), "days")),
    days.discarded =
      floor(lubridate::time_length(difftime(DATE.DISCARDED, REFERRED.DATE), "days"))
  ) %>% # days for missing DATE.TRANSFERRED will be NA, would be removed in KM plot
  mutate(Diagnosis = factor(Diagnosis.Code, levels=1:10, 
                            labels=c("Seminoma", "Teratoma", "Hodgkins disease", 
                                     "non-Hodgkins lymphoma", "Leukemia", "Sarcoma", 
                                     "Other cancers", "non-Cancer", "Myeloma", 
                                     "Marrow dysplasias")))

table(cryoadf$Transfer,useNA = 'ifany')
table(cryoadf$Deceased,useNA = 'ifany')
table(cryoadf$Discarded,useNA = 'ifany')
table(cryoadf$Diagnosis, useNA = 'ifany')

summary(cryoadf$days.transferred)
summary(cryoadf$days.deceased)
summary(cryoadf$days.discarded)

# --------------------------

# KM plot ------------------

library(ggsurvfit)

fit.transfer <- survfit(Surv(days.transferred/365.25,Transfer) ~ 1, data = cryoadf)
fit.deceased <- survfit(Surv(days.deceased/365.25,Deceased) ~ 1, data = cryoadf)
fit.discarded <- survfit(Surv(days.discarded/365.25,Discarded) ~ 1, data = cryoadf)

library("survminer")

ggsurv3 <- function(fit,data,title) {
  ggsurvplot(fit, data, 
             break.time.by = 3, 
             cumevents = TRUE,
             tables.y.text = FALSE,
             xlab = "Time (years)",
             #xlim = c(0,43),
             legend = "none",
             title = title,
             conf.int = TRUE, 
             risk.table = TRUE,
             tables.height = 0.15,
             tables.theme = theme_minimal(),
             legend.title="",
             ggtheme = theme_light(),
             size = 1,
             conf.int.style = "step",
             surv.median.line = "hv"
  ) 
}

ggsurv3(fit.transfer,cryoadf,"Time to Transfer")
ggsurv3(fit.deceased,cryoadf,"Time to Deceased")
ggsurv3(fit.discarded,cryoadf,"Time to Discarded")

fit.transfer <- survfit(Surv(days.transferred/365.25,Transfer) ~ Diagnosis_updt, data = cryoadf)
fit.deceased <- survfit(Surv(days.deceased/365.25,Deceased) ~ Diagnosis_updt, data = cryoadf)
fit.discarded <- survfit(Surv(days.discarded/365.25,Discarded) ~ Diagnosis_updt, data = cryoadf)

ggsurv3.Dia <- function(fit,data,title) {
  ggsurvplot(fit, data, 
             break.time.by = 3, 
             #pval = TRUE,
             #cumevents = TRUE,
             xlab = "Time (years)",
             # legend = "none",
             title = title,
             #conf.int = TRUE, 
             #conf.int.style = "step",
             surv.median.line = "hv",
             #risk.table = TRUE,
             #tables.height = 0.15,
             #tables.theme = theme_minimal(),
             #risk.table.y.text = FALSE,
             legend.title="",
             legend.labs = c("Seminoma", "Teratoma", "Hodgkins disease", 
                             "non-Hodgkins lymphoma", "Leukemia", "Sarcoma", 
                             "Other cancers", "non-Cancer", "Myeloma", 
                             "Marrow dysplasias"),
             ggtheme = theme_light(),
             size = 1
  ) 
}

ggsurv3.Dia <- function(fit,data,title) {
  ggsurvplot(fit, data, 
             break.time.by = 3, 
             #pval = TRUE,
             #cumevents = TRUE,
             xlab = "Time (years)",
             # legend = "none",
             title = title,
             #conf.int = TRUE, 
             #conf.int.style = "step",
             surv.median.line = "hv",
             #risk.table = TRUE,
             #tables.height = 0.15,
             #tables.theme = theme_minimal(),
             #risk.table.y.text = FALSE,
             legend.title="",
             legend.labs = c("Seminoma", "Teratoma", "Hodgkins disease", 
                             "non-Hodgkins lymphoma", "Leukemia", "Sarcoma", 
                             "Other cancers", "non-Cancer", "Myeloma", 
                             "Marrow dysplasias","Melanoma","Colorectal cancer",
                             "Brain cancer","Prostate cancer"),
             ggtheme = theme_light(),
             size = 1
  ) 
}

ggsurv3.Dia(fit.transfer,cryoadf,"Time to Transfer: by Diagnosis")
ggsurv3.Dia(fit.deceased,cryoadf,"Time to Deceased: by Diagnosis")
ggsurv3.Dia(fit.discarded,cryoadf,"Time to Discarded: by Diagnosis")

fit.discard.reason <- survfit(Surv(days.discarded/365.25,Discarded) ~ discard_reason, data = cryoadf)
ggsurvplot(fit.discard.reason, data = cryoadf, 
           break.time.by = 3, 
           pval = TRUE,
           #cumevents = TRUE,
           xlab = "Time (years)",
           title = "Time to Discarded, by simplified reasons",
           conf.int = TRUE, 
           #risk.table = TRUE,
           tables.height = 0.2,
           tables.theme = theme_minimal(),
           #risk.table.y.text = FALSE,
           legend.title="", # remove "Strata"
           legend.labs = c("DECEASED","RECOVERY","OTHER CLINICAL REASONS","LTFU","UNKNOWN"),
           ggtheme = theme_light(),
           size = 1,
           conf.int.style = "step",
           surv.median.line = "hv"
)
fit.discard.reason <- survfit(Surv(days.discarded/365.25,Discarded) ~ REASON.FOR.DISCARD, data = cryoadf)
ggsurvplot(fit.discard.reason, data = cryoadf, 
           break.time.by = 3, 
           #pval = TRUE,
           #cumevents = TRUE,
           xlab = "Time (years)",
           title = "Time to Discarded, by reasons",
           #conf.int = TRUE, 
           #risk.table = TRUE,
           tables.height = 0.2,
           tables.theme = theme_minimal(),
           #risk.table.y.text = FALSE,
           legend.title="", # remove "Strata"
           legend.labs = c("CAFAT AUTHORISED","CLINIC MEETING","CONSENT EXPIRED",
                           "DECEASED","DOCTOR REQUEST","LTFU",
                           "NIL PARTNER CONTACT","NO LONGER REQUIRED",
                           "PATIENT CONSENT","PATIENT REQUEST",
                           "RECOVERY OF SPERMATOGENESIS","RETURNED FERTILITY",
                           "UNKNOWN"," VASECTOMY"),
           ggtheme = theme_light(),
           size = 1,
           conf.int.style = "step",
           surv.median.line = "hv"
)

# --------------------------

# table1 --------------
fac <- cryoadf %>%
  mutate(transfer = factor(Transfer, levels=c("1","0"), 
                           labels=c("Transferred","Not Transferred")),
         deceased = factor(Deceased, levels=c("1","0"),
                           labels=c("Deceased","Not Deceased")),
         discarded = factor(Discarded, levels=c("1","0"),
                            labels=c("Discarded","Not Discarded"))) %>%
  expss::apply_labels(transfer = "Transfer",
                      deceased = "Deceased",
                      discarded = "Discarded")
library(table1)
table1(~ transfer, 
       data=fac,
       caption="Transfer: cryo storage")
table1(~ Diagnosis | transfer, 
       data=fac,
       overall=c(left="Total"),
       caption="Diagnosis category")

pvalue <- function(x, ...) {
  # Construct vectors of data y, and groups (strata) g
  y <- unlist(x)
  g <- factor(rep(1:length(x), times=sapply(x, length)))
  if (is.numeric(y)) {
    # For numeric variables, perform a standard 2-sample t-test
    p <- t.test(y ~ g)$p.value
  } else {
    # For categorical variables, perform a chi-squared test of independence
    p <- chisq.test(table(y, g))$p.value
  }
  # Format the p-value, using an HTML entity for the less-than sign.
  # The initial empty string places the output on the line below the variable label.
  c("", sub("<", "&lt;", format.pval(p, digits=3, eps=0.001)))
}
table1(~ Transfer + Deceased + Discarded | Diagnosis, 
       data=fac[!is.na(fac$Diagnosis),],
       topclass="Rtable1-grid Rtable1-shade Rtable1-times",
       render="FREQ (PCT%)",
       overall = F,
       extra.col=list(`P-value`=pvalue),
       caption="Diagnosis category") 
# --------------------------

# data update: 20240513 ----------

updt <- read.csv("cryoupdate_20240513.csv", na.strings = c("",NA))
updt <- updt %>% rename(ID = ?..ID) %>%
  select(-starts_with("X")) %>% filter(!is.na(ID)) %>%
  rename(Diagnosis.Code_updt = Diagnosis.Code) %>%
  select(ID, Diagnosis.Code_updt)

cryoadf <- cryoadf %>% left_join(updt, by="ID") %>%
  mutate(Diagnosis_updt = factor(Diagnosis.Code_updt, levels=1:14, 
                            labels=c("Seminoma", "Teratoma", "Hodgkins disease", 
                                     "non-Hodgkins lymphoma", "Leukemia", "Sarcoma", 
                                     "Other cancers", "non-Cancer", "Myeloma", 
                                     "Marrow dysplasias","Melanoma","Colorectal cancer",
                                     "Brain cancer","Prostate cancer")))

cryoadf <- cryoadf %>%
  #rename(storage = In.Storage.vs.No.stored.material) %>%
  mutate(age = floor(lubridate::interval(DOB.FIX, REFERRED.DATE) / lubridate::years(1)),
         n_stored = as.numeric(gsub("\\ |\\*","",No..COLLECTIONS.STORED)),
         marriage = case_when(
           grepl("DIVORCED",AT.CRYO.M.S.D.O) ~ "Divorced",
           grepl("ENGAGED",AT.CRYO.M.S.D.O) ~ "Engaged",
           grepl("SEPARATED",AT.CRYO.M.S.D.O) ~ "Separated",
           grepl("S",AT.CRYO.M.S.D.O) ~ "Single",
           grepl("D",AT.CRYO.M.S.D.O) ~ "Defacto",
           grepl("M",AT.CRYO.M.S.D.O) ~ "Married",
           TRUE ~ NA
         ),
         fu = case_when(
           grepl("YES",F.U.VISIT) ~ "YES",
           grepl("NO",F.U.VISIT) ~ "NO",
           TRUE ~ NA
         ),
         n_fu = as.numeric(gsub("\\ |\\*","",No....F.U.VISITS)),
         sperm_seen = case_when(
           grepl("DID NOT COLLECT",SPERM.SEEN) ~ NA,
           grepl("NO",SPERM.SEEN) ~ "NO",
           grepl("YES",SPERM.SEEN) ~ "YES",
           TRUE ~ NA
         )) %>%
  mutate(n_straws = as.numeric(gsub("\\ |\\*","",No..STRAWS))) %>%
  mutate(n_straws = ifelse(is.na(n_straws) & !is.na(No..STRAWS),0,n_straws)) %>%
  mutate(marriage = factor(marriage, 
                           levels=c("Married","Defacto","Single","Engaged",
                                    "Divorced","Separated"))) %>%
  # impute age and dates
  mutate(age = ifelse(is.na(age), as.numeric(AGE.at.COLLECTION), age),
         DOB.FIX = as.Date(ifelse(is.na(DOB.FIX), REFERRED.DATE - years(age), DOB.FIX), origin="1970-01-01"),
         REFERRED.DATE = as.Date(ifelse(is.na(REFERRED.DATE), DOB.FIX + years(age), REFERRED.DATE), origin="1970-01-01")) %>%
  mutate(age = ifelse(age == -3, 27, age),
         DOB.FIX = as.Date(ifelse(ID==2543, DOB.FIX - years(30), DOB.FIX), origin="1970-01-01")) %>%
  # impute yrs.stored
  mutate(yrs_stored = as.numeric(YRS.STORED)) %>%
  mutate(yrs_stored = ifelse(is.na(yrs_stored),
                             ifelse(storage == "No stored material", 
                                    round(interval(REFERRED.DATE, DATE.DISCARDED) / years(1), 1),
                                    round(interval(REFERRED.DATE, as.Date("2024-04-08", origin="1970-01-01")) / years(1), 1)),
                             yrs_stored)) %>%
  mutate(yrs_stored = ifelse(is.na(yrs_stored) & !is.na(YRS.STORED),
                             as.numeric(gsub("<","",YRS.STORED)) - 0.5,
                             yrs_stored)) %>%
  mutate(yrs_stored = ifelse(yrs_stored > 1000, NA, yrs_stored))
                             
# the relationship between yrs and dates not being logical
yrs <- cryoadf %>%
  mutate(yrs_stored = round(lubridate::time_length(
    difftime(coalesce(DATE.DISCARDED, DATE.TRANSFERRED, DATE.DECEASED,
                      as.Date("2024-04-08")), REFERRED.DATE), "years"),1)) %>%
  relocate(yrs_stored,.after=YRS.STORED) %>%
  mutate(DATA.DATE=as.Date("2024-04-08", original="1970-01-01")) %>%
  select(ID, REFERRED.DATE, storage, DATE.DISCARDED, DATE.TRANSFERRED, DATE.DECEASED, DATA.DATE, YRS.STORED, yrs_stored)
yrs1 <- cryoadf %>%
  mutate(yrs_stored = ifelse(storage=="In storage",YRS.STORED,
                             round(lubridate::time_length(
                               difftime(DATE.DISCARDED,REFERRED.DATE), "years"),1))) %>%
  relocate(yrs_stored,.after=YRS.STORED) %>%
  mutate(DATA.DATE=as.Date("2024-04-08", original="1970-01-01")) %>%
  select(ID, REFERRED.DATE, storage, DATE.DISCARDED, DATE.TRANSFERRED, DATE.DECEASED, DATA.DATE, YRS.STORED, yrs_stored)

cryoadf <- cryoadf %>% 
  expss::apply_labels(age = "Age",
                      n_stored = "No. stored",
                      marriage = "Marriage",
                      fu = "Follow up",
                      n_fu = "No. follow up",
                      storage = "Storage",
                      sperm_seen = "Sperm seen",
                      n_straws = "No. straws",
                      yrs_stored = "Years stored",
                      Diagnosis_updt = "Diagnosis")

fac <- cryoadf %>%
  mutate(transfer = factor(Transfer, levels=c("1","0"), 
                           labels=c("Transferred","Not Transferred")),
         deceased = factor(Deceased, levels=c("1","0"),
                           labels=c("Deceased","Not Deceased")),
         discarded = factor(Discarded, levels=c("1","0"),
                            labels=c("Discarded","Not Discarded"))) %>%
  expss::apply_labels(transfer = "Transfer",
                      deceased = "Deceased",
                      discarded = "Discarded") %>%
  select(ID, Diagnosis_updt:discarded, storage)

# --------------------------

# data cleaning: 20240515 -----

# categories
cryoadf <- cryoadf %>%
  mutate(
    marriage3 = factor(
      case_when(
        marriage %in% c("Married","Defacto") ~ "Married or Defacto",
        marriage %in% c("Single","Engaged") ~ "Single",
        marriage %in% c("Divorced","Separated") ~ "Divorced or Separated",
        TRUE ~ NA
        ), 
      levels = c("Single","Married or Defacto","Divorced or Separated")
      ),
    
    n_children = case_when(
      grepl("1",AT.CRYO.No..OF.CHILDREN) ~ "1",
      AT.CRYO.No..OF.CHILDREN %in% c("2","2*") ~ "2",
      as.numeric(gsub("\\ |\\*|\\+","",AT.CRYO.No..OF.CHILDREN)) >= 2 ~ "2+",
      TRUE ~ "0"
      ),
    
    area = factor(
      case_when(
        gsub("^\\s+|\\s$","",HOSPITAL) %in% # whitespace at the beginning or the end of a string
          c("ARMIDALE HOSPITAL","BOWRAL","CENTRAL COAST CA. CENTRE",
            "DUBBO BASE HOSPITAL","GOSFORD","GOSFORD PRIVATE HOSPITAL",
            "ILLAWARRA CANCER CENTRE","ILLAWARRA PRIVATE CANCER CENTRE",
            "JOHN HUNTER HOSP.","MID-NORTH COAST CANCER INST.","NEWCASTLE",
            "NORWEST PRIVATE","NOWRA","ORANGE","ORANGE BASE","PORT MACQUARIE",
            "SHELL HARBOUR","SHOALHAVEN","SHOALHAVEN CA CENTRE",
            "SHOALHAVEN CANCER CENTRE","SHOALHAVEN HOSPITAL",
            "SOUTH COAST CA CENTRE","SOUTH COAST UROLOGY","SOUTHCOAST UROLOGY",
            "TAMWORTH","THE NEW MAITLAND HOSPITAL","WODEN VALLEY - ACT",
            "WOLLONGONG","WOLLONGONG PRIVATE","WOLLONGONG/SHOALHAVEN") 
        ~ "non-Urban",
        is.na(HOSPITAL) ~ NA,
        TRUE ~ "Urban"
        ),
      levels = c("Urban","non-Urban")
      ),
    
    straws0 = case_when(
      No..STRAWS %in% c("DID NOT ATTEND","DID NOT COLLECT") ~ "DID NOT COLLECT",
      No..STRAWS == "DISCONTINUED - POOR SAMPLE" ~ "DID NOT FREEZE",
      grepl("DID NOT FREEZE",No..STRAWS) ~ "DID NOT FREEZE",
      n_straws == 0 ~ No..STRAWS,
      TRUE ~ "Straws > 0"
    ),
    
    REASON.FOR.DISCARD = case_when(
      REASON.FOR.DISCARD == "PATIENT CONSENT " ~ "PATIENT CONSENT",
      REASON.FOR.DISCARD == "RECOVERY OF SPERMATOGENESIS " ~ "RECOVERY OF SPERMATOGENESIS",
      is.na(REASON.FOR.DISCARD) ~ NA,
      TRUE ~ REASON.FOR.DISCARD
    ),
    discard_reason = factor(
      case_when(
        REASON.FOR.DISCARD %in% c("LTFU", "DECEASED", "UNKNOWN") ~ REASON.FOR.DISCARD,
        gsub("^\\ |\\ $","",REASON.FOR.DISCARD) %in% 
          c("RECOVERY OF SPERMATOGENESIS","RETURNED FERTILITY") ~ "RECOVERY",
        is.na(REASON.FOR.DISCARD) ~ NA,
        TRUE ~ "OTHER CLINICAL REASONS"
        ),
      levels = c("DECEASED","RECOVERY","OTHER CLINICAL REASONS","LTFU","UNKNOWN")
    )
  )

# variable labels
cryoadf <- cryoadf %>% 
  apply_labels(age = "Age at storage",
               n_fu = "Number of follow-ups",
               fu = "Follow-up",
               n_stored = "Number of storage visits",
               n_straws = "Number of straws",
               marriage3 = "Marriage",
               n_children = "Number of children at storage",
               area = "Hospital locations",
               straws0 = "Reasons for zero straws",
               discard_reason = "Reasons for discard") %>%
  relocate(Diagnosis, .after = Diagnosis.Code) %>%
  relocate(storage, .before = Diagnosis.Code_updt)

# table 1 dataframe
fac <- cryoadf %>%
  mutate(transfer = factor(Transfer, levels=c("1","0"), 
                           labels=c("Transferred","Not Transferred")),
         deceased = factor(Deceased, levels=c("1","0"),
                           labels=c("Deceased","Not Deceased")),
         discarded = factor(Discarded, levels=c("1","0"),
                            labels=c("Discarded","Not Discarded"))) %>%
  expss::apply_labels(transfer = "Transfer",
                      deceased = "Deceased",
                      discarded = "Discarded") %>%
  select(ID, storage:discarded, REASON.FOR.DISCARD)

# age difference > 2
age <- cryoadf %>% 
  mutate(AGE = as.numeric(substring(AGE.at.COLLECTION,1,2)),
         age_diff = abs(AGE - age)) %>% 
  select(ID, PATIENT.NAME, MRN, DOB.FIX, REFERRED.DATE, AGE.at.COLLECTION, age, age_diff) %>%
  filter(age > 0 & age_diff > 2 & AGE.at.COLLECTION != "32-37")
write.csv(age, file="age difference lager than 2.csv", row.names=FALSE, na="")

# Q1, Q3, 90% function in table1()
render.NEW <- function(x, name, data2, ...) {
  MIN <- min(x, na.rm = T)
  MAX <- max(x, na.rm = T)
  mean <- mean(x, na.rm = T)
  sd <- sd(x, na.rm = T)
  median <- median(x, na.rm = T)
  Q1 <- quantile(x, 0.25, na.rm = T)
  Q3 <- quantile(x, 0.75, na.rm = T)
  p90 <- quantile(x, 0.9, na.rm = T)
  N = length(x) - sum(is.na(x))
  
  out <- c("",
           "Mean (SD)" = paste0(sprintf("%.1f", mean), " (", sprintf("%.1f", sd), ")"),
           "Median [Min, Max]" = paste0(sprintf("%.1f", median), " [", sprintf("%.1f", MIN), ", ", sprintf("%.1f", MAX), "]"),
           "Q1, Q3, P90" = paste0(sprintf("%.1f", Q1), ", ", sprintf("%.1f", Q3), ", ", sprintf("%.1f", p90)),
           "N" = N
           )
  out
}
table1(~ n_fu + yrs_stored | transfer, data=fac, render.continuous = render.NEW)

rndr <- function(x, name, ...) { # different statistics for different variabls
  if (!is.numeric(x)) return(render.categorical.default(x))
  what <- switch(name,
                 age = c("Mean (SD)", "Median [Min, Max]", "Q1, Q3"),
                 n_fu = c("Mean (SD)", "Median [Q1, Q3]"),
                 yrs_stored = c("Mean (SD)", "Median [Q1, Q3]"))
  parse.abbrev.render.code(c("", what))(x)
}
table1(~ age + marriage + n_fu + yrs_stored | transfer, data=fac, 
       #render.continuous = render.NEW
       #render = rndr
       render.continuous=c(.="Mean (SD)", .="Median [Min, Max]", .="Q1, Q3")
       )

# --------------------------

# data cleaning: 20240520 ----
# AT.CRYO.CHILDREN.Y.N
cryoadf <- cryoadf %>% 
  mutate(children = 
    case_when( 
      AT.CRYO.CHILDREN.Y.N == "PREGNANT" ~ "YES",
      grepl("DIU",AT.CRYO.CHILDREN.Y.N) ~ "YES",
      grepl("U",AT.CRYO.CHILDREN.Y.N) ~ NA,
      grepl("N",AT.CRYO.CHILDREN.Y.N) ~ "NO",
      is.na(AT.CRYO.CHILDREN.Y.N) ~ NA,
      TRUE ~ "YES"
      )
    ) %>%
  relocate(children, .before=n_children) %>%
  # PREG => 0 children, UNKNOW => NA
  mutate(N_children = as.numeric(gsub("\\ |\\*|\\+|\\/|[a-zA-Z]+","",AT.CRYO.No..OF.CHILDREN)),
         N_children = ifelse(N_children > 10, 0, N_children),
         N_children = ifelse(is.na(N_children) & !is.na(children), 0, N_children),
         N_children = ifelse(AT.CRYO.CHILDREN.Y.N == "UNKNOWN",NA,N_children)) %>%
  relocate(N_children, .after=n_children) %>%
  mutate(children = ifelse(N_children > 0 & !is.na(N_children), "YES", children)) %>%
  mutate(children = factor(children, levels=c("YES","NO"))) %>%
  # mutate n_children
  mutate(n_children = case_when(
    N_children == 0 ~ "0",
    N_children == 1 ~ "1",
    N_children == 2 ~ "2",
    is.na(N_children) ~ NA,
    TRUE ~ "2+"
  )) %>%
  mutate(marriage3 = factor(
    case_when(
      marriage %in% c("Married","Defacto") ~ "Married",
      marriage %in% c("Single","Engaged") ~ "Single",
      marriage %in% c("Divorced","Separated") ~ "Divorced",
      TRUE ~ NA
    ), 
    levels = c("Single","Married","Divorced")
  )) %>%
  apply_labels(children="Children at storage - Y/N",
               n_children = "Number of children at storage",
               N_children = "Number of children at storage",
               marriage3 = "Marriage")

# table 1 dataframe
fac <- cryoadf %>%
  mutate(transfer = factor(Transfer, levels=c("1","0"), 
                           labels=c("Transferred","Not Transferred")),
         deceased = factor(Deceased, levels=c("1","0"),
                           labels=c("Deceased","Not Deceased")),
         discarded = factor(Discarded, levels=c("1","0"),
                            labels=c("Discarded","Not Discarded"))) %>%
  expss::apply_labels(transfer = "Transfer",
                      deceased = "Deceased",
                      discarded = "Discarded") %>%
  select(ID, storage:discarded, REASON.FOR.DISCARD)

# --------------------------

# postcode: 20240521 -------

sydney = c(2000,2006,2007,2008,2009,2010,2011,2015,2016,2017,2018,2019,2020,2021,2022,2023,2024,2025,2026,2027,2028,2029,2030,
           2031,2032,2033,2034,2035,2036,2037,2038,2039,2040,2041,2042,2043,2044,2045,2046,2047,2048,2049,2050,2052,2060,2061,
           2062,2063,2064,2065,2066,2067,2068,2069,2070,2071,2072,2073,2074,2075,2076,2077,2079,2080,2081,2082,2083,2084,2085,
           2086,2087,2088,2089,2090,2092,2093,2094,2095,2096,2097,2099,2100,2101,2102,2103,2104,2105,2106,2107,2108,2109,2110,
           2111,2112,2113,2114,2115,2116,2117,2118,2119,2120,2121,2122,2123,2125,2126,2127,2128,2129,2130,2131,2132,2133,2134,
           2135,2136,2137,2138,2139,2140,2141,2142,2143,2144,2145,2146,2147,2148,2150,2151,2152,2153,2154,2155,2156,2157,2158,
           2159,2160,2161,2162,2163,2164,2165,2166,2167,2168,2170,2171,2172,2173,2174,2175,2176,2177,2178,2179,2190,2191,2192,
           2193,2194,2195,2196,2197,2198,2199,2200,2203,2204,2205,2206,2207,2208,2209,2210,2211,2212,2213,2214,2216,2217,2218,
           2219,2220,2221,2222,2223,2224,2225,2226,2227,2228,2229,2230,2231,2232,2233,2234,2555,2556,2557,2558,2559,2560,2563,
           2564,2565,2566,2567,2568,2569,2570,2571,2572,2573,2574,2745,2747,2748,2749,2750,2752,2753,2754,2755,2756,2757,2758,
           2759,2760,2761,2762,2763,2765,2766,2767,2768,2769,2770,2773,2774,2775,2776,2777,2778,2779,2780,2782,2783,2784,2785,2786,2787,2790)
newcastle = c(2259,2264,2265,2267,2278,2280,2281,2282,2283,2284,2285,2286,2287,2289,2290,2291,2292,2293,2294,
              2295,2296,2297,2298,2299,2300,2302,2303,2304,2305,2306,2307,2308,2318,2322,2323)
central = c(2083,2250,2251,2256,2257,2258,2259,2260,2261,2262,2263,2775)
wollongong = c(2500,2502,2505,2506,2508,2515,2516,2517,2518,2519,2522,2525,2526,2527,2528,2529,2530,2533,2534,2535,2560,2577)
regional = c(2311:2312,2328:2411,2420:2490,2536:2551,2575:2594,2618:2739,2787:2899)
remote = c(2356,2386,2387,2396,2405,2406,2872,2875,2825,2826,2329,2832,2833,2834,2835,2836,2838,2839,2840,2873,2878,2879,2898)
post <- data.frame(
  region = c(rep("Sydney", length(sydney)),
             rep("Newcastle", length(newcastle)),
             rep("Central coast", length(central)),
             rep("Wollongong", length(wollongong)),
             rep("NSW Regional", length(regional)),
             rep("NSW Remote", length(remote))),
  postcode = as.character(c(sydney, newcastle, central, wollongong, regional, remote))
) %>%
  group_by(postcode) %>%
  # a <- post %>% group_by(postcode) %>% filter(n() > 1) %>% arrange(postcode)
  # write.csv(a,file="postcode duplication.csv",row.names=FALSE, na="")
  filter(row_number()==1) # keep first obs. per group

cryoadf <- cryoadf %>% 
  mutate(postcode = ifelse(grepl("[a-zA-Z]+", POSTCODE), NA, POSTCODE),
         postcode = ifelse(POSTCODE %in% c("820","O820"), "0820", postcode),
         postcode = ifelse(POSTCODE == "O810", "0810", postcode)) %>%
  left_join(post, by="postcode") %>%
  mutate(region = ifelse(is.na(region), "NSW Remote", region)) %>%
  mutate(region = factor(region, levels = c("Sydney","Newcastle","Central coast","Wollongong","NSW Regional","NSW Remote"))) %>%
  apply_labels(postcode = "Postcode",
               region = "Region")
#b <- cryoadf %>% select(postcode,region) %>% filter(region == "NSW Remote" & !is.na(postcode)) %>% arrange(postcode)
#write.csv(b,file="postcode remote.csv",row.names = FALSE)

# table 1 dataframe
fac <- cryoadf %>%
  mutate(transfer = factor(Transfer, levels=c("1","0"), 
                           labels=c("Transferred","Not Transferred")),
         deceased = factor(Deceased, levels=c("1","0"),
                           labels=c("Deceased","Not Deceased")),
         discarded = factor(Discarded, levels=c("1","0"),
                            labels=c("Discarded","Not Discarded"))) %>%
  expss::apply_labels(transfer = "Transfer",
                      deceased = "Deceased",
                      discarded = "Discarded") %>%
  select(ID, storage:discarded, REASON.FOR.DISCARD)

# --------------------------

# KM plot: 20240522 -------

fit.transfer <- survfit(Surv(days.transferred/365.25,Transfer) ~ 1, data = cryoadf)
fit.deceased <- survfit(Surv(days.deceased/365.25,Deceased) ~ 1, data = cryoadf)
fit.discarded <- survfit(Surv(days.discarded/365.25,Discarded) ~ 1, data = cryoadf)

quantile(fit.transfer, probs = c(0.25, 0.5, 0.75, 0.9))$quantile -> transfer # 1.0 2.4312115 6.0 10.5
quantile(fit.deceased, probs = c(0.25, 0.5, 0.75, 0.9))$quantile -> deceased # 0.9 1.6591376 3.3 6.0
quantile(fit.discarded, probs = c(0.25, 0.5, 0.75, 0.9))$quantile -> discarded # 4.8 7.690623 11.1 15.3
time <- rbind(transfer,deceased,discarded)
colnames(time) <- c("25% to outcome","50% to outcome","75% to outcome","90% to outcome")
rownames(time) <- NULL
# time <- format(round(time, 1), nsmall=1)
# time <- time %>% mutate_if(is.numeric, as.character)
# time <- time[,5:1] # reorder columns

library("survminer")

ggsurv3com <- function(fit,data,title) {
  ggsurvplot_combine(fit, data, 
             break.time.by = 3, 
             cumevents = TRUE,
             #tables.y.text = FALSE,
             #xscale = "d_y", # xscale = 365.25,
             xlab = "Time (years)",
             #xlim = c(0,43),
             legend = c(0.42,0.75),
             legend.title = "Time to outcomes",
             legend.labs = c("Transfer", "Deceased", "Discarded"),
             title = title,
             font.main = c(16, "bold", "black"),
             font.tickslab = c(12, "plain", "black"),
             conf.int = TRUE, 
             risk.table = "absolute",
             tables.col = "strata",
             tables.height = 0.15,
             tables.theme = theme_cleantable(),
             #risk.table.y.text = FALSE, # risk.table.y.text = tables.y.text,
             ggtheme = theme_light(),
             size = 1,
             conf.int.style = "step"
  ) 
}

fit <- list(Transfer=fit.transfer, Deceased=fit.deceased, Discarded=fit.discarded)
ggsurv3com(fit,cryoadf,"Time to Transfer, Deceased and Discarded") -> ggsurv
ggsurv$plot <- ggsurv$plot + 
  theme(legend.key.size = unit(1.45, 'lines'),
        legend.spacing.y = unit(0.2,"cm"),
        legend.title = element_text(size = 13, color = "black", face = "bold"),
        legend.text = element_text(size = 12, color = "black", face = "plain"),
        #axis.text.x = element_text(size = 13, color = "black", face = "bold"),
        #axis.text.y = element_text(size = 13, color = "black", face = "bold"),
        axis.title.x = element_text(size = 13, color = "black", face = "bold"),
        axis.title.y = element_text(size = 13, color = "black", face = "bold")) +
  geom_segment(aes(x = 0, y = 0.5, xend = 7.690623, yend = 0.5), linetype="dashed") +
  geom_segment(aes(x = 7.690623, y = 0, xend = 7.690623, yend = 0.5), linetype="dashed") +
  geom_segment(aes(x = 1.6591376, y = 0, xend = 1.6591376, yend = 0.5), linetype="dashed") +
  geom_segment(aes(x = 2.4312115, y = 0, xend = 2.4312115, yend = 0.5), linetype="dashed") +
  annotation_custom(gridExtra::tableGrob(format(round(time, 1), nsmall=1)), 
                    xmin=21.5, xmax=43, ymin=0.7, ymax=0.85)
ggsurv

# --------------------------

# KM plot: 20240527 --------

cryoadf <- cryoadf %>%
  mutate(
    Disease = factor(Diagnosis.Code_updt, 
                     labels=c("Testis cancer","Testis cancer","Lymphoma","Lymphoma",
                              "Leukemia","Sarcoma","Other cancer","Non cancer",
                              "Other cancer","Other cancer","Other cancer",
                              "Colorectal cancer","Brain cancer","Other cancer"))) %>%
  mutate(
    Disease = factor(Disease,
                     levels=c("Testis cancer","Lymphoma","Leukemia","Sarcoma",
                              "Colorectal cancer","Brain cancer","Other cancer","Non cancer"))) %>%
  relocate(Disease, .after=Diagnosis_updt)

fit.transfer <- survfit(Surv(days.transferred/365.25,Transfer) ~ Disease, data = cryoadf)
fit.deceased <- survfit(Surv(days.deceased/365.25,Deceased) ~ Disease, data = cryoadf)
fit.discarded <- survfit(Surv(days.discarded/365.25,Discarded) ~ Disease, data = cryoadf)

quantile(fit.transfer, probs = c(0.25, 0.5, 0.75, 0.9))$quantile -> transfer
quantile(fit.deceased, probs = c(0.25, 0.5, 0.75, 0.9))$quantile -> deceased
quantile(fit.discarded, probs = c(0.25, 0.5, 0.75, 0.9))$quantile -> discarded
colnames(transfer) <- c("25% to transfer","50% to transfer","75% to transfer","90% to transfer")
colnames(deceased) <- c("25% to deceased","50% to deceased","75% to deceased","90% to deceased")
colnames(discarded) <- c("25% to discarded","50% to discarded","75% to discarded","90% to discarded")
rownames(transfer) <- NULL
rownames(deceased) <- NULL
rownames(discarded) <- NULL

ggsurv.Dia <- function(fit,data,title) {
  ggsurvplot(fit, data, 
             break.time.by = 3, 
             pval = TRUE,
             pval.coord = c(15,0.4),
             #cumevents = TRUE,
             xlab = "Time (years)",
             title = title,
             #conf.int = TRUE, 
             #conf.int.style = "step",
             surv.median.line = "hv",
             # legend = "none",
             legend = c(0.4,0.75),
             legend.title = "Time to outcomes",
             legend.labs = c("Testis cancer","Lymphoma","Leukemia","Sarcoma",
                             "Colorectal cancer","Brain cancer","Other cancer","Non cancer"),
             ggtheme = theme_light(),
             size = 1
  ) 
}

ggsurv.Dia(fit.transfer,cryoadf,"Time to Transfer: by Disease") -> ggsurv
ggsurv$plot <- ggsurv$plot + 
  theme(legend.key.size = unit(1.45, 'lines'),
        legend.spacing.y = unit(0.2,"cm"),
        legend.title = element_text(size = 14, color = "black", face = "bold"),
        legend.text = element_text(size = 13, color = "black", face = "plain"),
        axis.title.x = element_text(size = 13, color = "black", face = "bold"),
        axis.title.y = element_text(size = 13, color = "black", face = "bold")) +
  annotation_custom(gridExtra::tableGrob(format(round(transfer, 1), nsmall=1)), 
                    xmin=12, xmax=24, ymin=0.7, ymax=0.85)
ggsurv

ggsurv.Dia(fit.deceased,cryoadf,"Time to Deceased: by Disease") -> ggsurv
ggsurv$plot <- ggsurv$plot + 
  theme(legend.key.size = unit(1.45, 'lines'),
        legend.spacing.y = unit(0.2,"cm"),
        legend.title = element_text(size = 14, color = "black", face = "bold"),
        legend.text = element_text(size = 13, color = "black", face = "plain"),
        axis.title.x = element_text(size = 13, color = "black", face = "bold"),
        axis.title.y = element_text(size = 13, color = "black", face = "bold")) +
  annotation_custom(gridExtra::tableGrob(format(round(deceased, 1), nsmall=1)), 
                    xmin=19, xmax=40.5, ymin=0.7, ymax=0.85)
ggsurv

ggsurv.Dia(fit.discarded,cryoadf,"Time to Discarded: by Disease") -> ggsurv
ggsurv$plot <- ggsurv$plot + 
  theme(legend.key.size = unit(1.45, 'lines'),
        legend.spacing.y = unit(0.2,"cm"),
        legend.title = element_text(size = 14, color = "black", face = "bold"),
        legend.text = element_text(size = 13, color = "black", face = "plain"),
        axis.title.x = element_text(size = 13, color = "black", face = "bold"),
        axis.title.y = element_text(size = 13, color = "black", face = "bold")) +
  annotation_custom(gridExtra::tableGrob(format(round(discarded, 1), nsmall=1)), 
                    xmin=18.8, xmax=41, ymin=0.7, ymax=0.85)
ggsurv

cryoadf <- cryoadf %>%
  mutate(
    discard_reason = factor(REASON.FOR.DISCARD, 
                            labels = c("Recovery","Administrative","Administrative",
                                       "Deceased","Administrative","Deceased",
                                       "Deceased","Recovery","Recovery",
                                       "Recovery","Recovery","Recovery",
                                       "Deceased","Recovery")),
    discard_reason = factor(discard_reason, levels=c("Recovery","Deceased","Administrative"))
  ) %>% apply_labels(discard_reason = "Discard reasons")

fit.discard.reason <- survfit(Surv(days.discarded/365.25,Discarded) ~ discard_reason, data = cryoadf)
ggsurvplot(fit.discard.reason, data = cryoadf, 
           break.time.by = 3, 
           pval = TRUE,
           pval.coord = c(13, 0.55),
           xlab = "Time (years)",
           title = "Time to Discarded, by reasons",
           conf.int = TRUE, 
           tables.height = 0.2,
           tables.theme = theme_minimal(),
           legend = c(0.6,0.8),
           legend.title="Time to discarded", # remove "Strata"
           legend.labs = c("Recovery","Deceased","Administrative"),
           ggtheme = theme_light(),
           size = 1,
           conf.int.style = "step",
           surv.median.line = "hv"
)

cryoadf <- cryoadf %>%
  mutate(fu = factor(fu, labels=c("No","Yes")),
         fu = factor(fu, levels=c("Yes","No"))) %>%
  apply_labels(fu = "Follow-up")
levels(cryoadf$children) <- c("Yes","No")

cryoadf <- cryoadf %>% 
  mutate(DATA.DATE = as.Date("2024-04-08")) %>%
  relocate(DATA.DATE, .after = DIAGNOSIS) %>%
  mutate(DAYS.transferred = 
           ifelse(is.na(TRANSFER), 
                  as.numeric(difftime(DATA.DATE, REFERRED.DATE, units="days")),
                  days.transferred)) %>%
  relocate(DAYS.transferred, .after = days.transferred) %>%
  mutate(DAYS.deceased = 
           ifelse(is.na(DECEASED), 
                  as.numeric(difftime(DATA.DATE, REFERRED.DATE, units="days")),
                  days.deceased)) %>%
  relocate(DAYS.deceased, .after = days.deceased) %>%
  mutate(DAYS.discarded = 
           ifelse(is.na(DISCARDED), 
                  as.numeric(difftime(DATA.DATE, REFERRED.DATE, units="days")),
                  days.discarded)) %>%
  relocate(DAYS.discarded, .after = days.discarded)

cryoadf <- cryoadf %>%
  mutate(sperm_seen = factor(sperm_seen, labels=c("No","Yes")),
         sperm_seen = factor(sperm_seen, levels=c("Yes","No"))) %>%
  expss::apply_labels(sperm_seen = "Sperm seen")

# table 1 dataframe
fac <- cryoadf %>%
  mutate(transfer = factor(Transfer, levels=c("1","0"), 
                           labels=c("Transferred","Not Transferred")),
         deceased = factor(Deceased, levels=c("1","0"),
                           labels=c("Deceased","Not Deceased")),
         discarded = factor(Discarded, levels=c("1","0"),
                            labels=c("Discarded","Not Discarded"))) %>%
  expss::apply_labels(transfer = "Transfer",
                      deceased = "Deceased",
                      discarded = "Discarded") %>%
  select(ID, storage:discarded, REASON.FOR.DISCARD)

# --------------------------

# table 1 template ------

tbl1 <- table1(~ age + marriage3 | Disease, data = cryoadf %>% filter(!is.na(Disease)))
library(flextable)
t1flex(tbl1) %>% save_as_docx(path = "tbl1.docx")
library(rvest)
as.data.frame(read_html(tbl1) %>% html_table(fill=TRUE)) -> a

library(gtsummary)
cryoadf %>% 
  select(age, area, region) %>%
  tbl_summary(
    by = area,
    type = all_continuous() ~ "continuous2", # multi-line summary
    statistic = list(
      all_continuous() ~ c(
        "{N_nonmiss}",
        "{mean} \u00b1 {sd}",
        "{median} ({p25}, {p75})",
        "{min}, {max}"),
      all_categorical() ~ "{n} / {N} ({p}%)"
    ),
    label = region ~ "Residence",
    digits = list(age ~ c(0,1,2,0,0,0,0,0)),
    missing_text = "(Missing)"
  ) %>%
  add_n() %>%
  add_overall() %>%
  #add_difference() %>% # Welch Two Sample t-test
  #add_q() %>%
  #add_stat_label() %>%
  add_p(pvalue_fun = ~ style_pvalue(.x, digits = 2),
        test = list(all_continuous() ~ "t.test",
                    all_categorical() ~ "chisq.test"),
        test.args = all_tests("t.test") ~ list(var.equal = TRUE)) # assume equal variance in the t-test

cryoadf %>% 
  tbl_summary(
    include = c(age, marriage3, fu, n_stored, n_straws, children),
    by = area,
    type = list(
      all_continuous() ~ "continuous2", # multi-line summary
      fu ~ "categorical",
      children ~ "categorical"
    ),
    statistic = 
      list(age ~ c("{mean} ({sd})", "{min}, {max}"),
           n_stored ~ c("{median} ({p25}, {p75})","{p90}")),
    digits = all_continuous() ~ 1,
    missing = "no"
  ) %>%
  add_n() %>%
  add_p(pvalue_fun = ~ style_pvalue(.x, digits = 2)) %>%
  modify_spanning_header(c("stat_1","stat_2") ~ "**Area**")

# Set theme
theme_gtsummary_journal(journal = "nejm")
theme_gtsummary_compact()
# Reset theme
reset_gtsummary_theme()

cryoadf %>%
  select(region, age, marriage3, children, n_stored, n_straws, n_fu, yrs_stored, Disease) %>%
  tbl_summary(
    by = Disease,
    type = list(
      all_continuous() ~ "continuous2",
      children ~ "categorical"
    ),
    statistic = list(
      all_continuous() ~ "{mean} ({sd})",
      all_categorical() ~ "{p}%"
    ),
    digits = all_continuous() ~ c(1,1,0,0,0),
    missing = "no"
  ) %>%
  add_overall() -> tbl
# tbl %>% as_gt() %>% gt::gtsave(filename = "table.docx")

tbl_t <- t(tbl$table_body)
tbl_t <- tbl_t[c(3,5:nrow(tbl_t)),c(2,9,11,16,18,20,22,24)]
tbl_t <- cbind(c(NA,NA,"Overall",tbl$df_by$by_chr),
               c(NA,NA,unique(tbl$df_by$N),tbl$df_by$n),
               tbl_t)
rownames(tbl_t) <- NULL
colnames(tbl_t) <- c("Disease","Number","Residence (Sydney)","Age (years)",
                     "Marital (single)","Children (none)","Storage visits",
                     "Straws (number)","Follow-up visits","Years stored")
tbl_t <- tbl_t[-c(1:2),]
tbl_t <- tbl_t[c(2:9,1),]
#write.csv(tbl_t, "table_t.csv", row.names = F)
#sjPlot::tab_df(as_tibble(tbl_t), file = "output.doc", encoding = "Windows-1252")
tbl_t <- as_tibble(tbl_t) 

library(plyr);library(dplyr) # need to load dplyr after plyr
tbl_t$Disease <- aaply(tbl_t$Disease, 1, function(x)
  paste0("<span style='font-weight:bold'>", x, "</span") # change column style
)
library(htmlTable)
htmlTable::htmlTable(tbl_t,rnames = F) # html Table to Viewer and copy-paste to word

library(flextable)
tbl_t <- flextable(data = tbl_t) %>% 
  theme_zebra %>% 
  autofit %>%
  bold(j = 1, bold = TRUE) %>%
  align(j = 2, align = "right", part = "body") %>%
  align(j = 3:ncol(tbl_t), align = "center", part = "body")
tbl_t # See flextable in RStudio viewer
tmp <- tempfile(tmpdir = getwd(), fileext = ".docx") # Create a temp file, random name
library(officer)
read_docx() %>% 
  body_add_flextable(tbl_t) %>% 
  print(target = tmp) # Create a docx file
browseURL(tmp) # open word document

# --------------------------

# data manipulation: 20240603 ------

cryoadf <- cryoadf %>% 
  mutate(
    region3 = factor(region, 
                     labels=c("Sydney", "Rural cities", "Rural cities", "Rural cities", 
                              "NSW regional/remote", "NSW regional/remote"))) %>%
  apply_labels(region3 = "Region")

cryoadf <- cryoadf %>%
  apply_labels(sperm_seen = "Sperm seen at follow-up")

cryoadf <- cryoadf %>%
  mutate(sperm_seen2 = 2 - as.integer(sperm_seen)) %>%
  expss::apply_labels(sperm_seen2 = "Sperm seen at follow-up")

# table 1 dataframe
fac <- cryoadf %>%
  mutate(transfer = factor(Transfer, levels=c("1","0"), 
                           labels=c("Transferred","Not Transferred")),
         deceased = factor(Deceased, levels=c("1","0"),
                           labels=c("Deceased","Not Deceased")),
         discarded = factor(Discarded, levels=c("1","0"),
                            labels=c("Discarded","Not Discarded"))) %>%
  expss::apply_labels(transfer = "Transfer",
                      deceased = "Deceased",
                      discarded = "Discarded") %>%
  select(ID, storage:discarded, REASON.FOR.DISCARD)

# --------------------------

save(cryo, cryoadf, fac, file="cryo.Rda")
write.csv(cryoadf, file="CRYO analysis data.csv", row.names=FALSE, na="")

library(Hmisc)
names(cryoadf) <- Hmisc::label(cryoadf)
write.csv(cryoadf, file="CRYO label.csv", row.names=FALSE, na="")

# COX model: 20240603 ---------
# Transfer
t1 = tbl_uvregression(
  cryoadf %>% select(Disease, region3, age, marriage3, n_children, n_stored, 
                     sperm_seen, n_straws, n_fu, DAYS.transferred, Transfer),
  method = coxph,
  y = Surv(DAYS.transferred/365.25,Transfer),
  exponentiate = TRUE
) %>%
  add_global_p() %>% 
  bold_p() %>%
  bold_labels() %>% 
  italicize_levels() %>%
  add_n(location = "level") %>%
  add_nevent(location = "level") 

mdl2 <- function(var) {
  fit <- coxph(Surv(DAYS.transferred/365.25,Transfer) ~ 
                 Disease + var, data = cryoadf)
  tbl_regression(fit, exponentiate = TRUE) %>% 
    add_global_p() %>% 
    bold_p() %>%
    add_n(location = "level") %>%
    add_nevent(location = "level") %>%
    remove_row_type(Disease, type = "all")
}
a1 = mdl2(cryoadf$region3)
a2 = mdl2(cryoadf$age)
a3 = mdl2(cryoadf$marriage3)
a4 = mdl2(cryoadf$n_children)
a5 = mdl2(cryoadf$n_stored)
a6 = mdl2(cryoadf$sperm_seen)
a7 = mdl2(cryoadf$n_straws)
a8 = mdl2(cryoadf$n_fu)
a1$table_body$variable <- rep("region3",length(a1$table_body$variable))
a2$table_body$variable <- rep("age",length(a2$table_body$variable))
a3$table_body$variable <- rep("marriage3",length(a3$table_body$variable))
a4$table_body$variable <- rep("n_children",length(a4$table_body$variable))
a5$table_body$variable <- rep("n_stored",length(a5$table_body$variable))
a6$table_body$variable <- rep("sperm_seen",length(a6$table_body$variable))
a7$table_body$variable <- rep("n_straws",length(a7$table_body$variable))
a8$table_body$variable <- rep("n_fu",length(a8$table_body$variable))
t2 = tbl_stack(list(a1,a2,a3,a4,a5,a6,a7,a8))

fit.Transfer <- coxph(Surv(DAYS.transferred/365.25,Transfer) ~ 
                        Disease + region3 + age + marriage3 + n_children + n_stored + 
                        sperm_seen + n_straws + n_fu, data = cryoadf)
t3 = tbl_regression(fit.Transfer, exponentiate = TRUE) %>% 
  add_global_p() %>% 
  bold_p() %>%
  add_n(location = "level") %>%
  add_nevent(location = "level")

tt = tbl_merge(list(t1,t2,t3), tab_spanner = c("**Univariate**", "**Univariate + Disease**", "**Multivariate**")) %>%
  modify_caption("**Table 1. Transfer**")
tt = tbl_merge(list(t1,t2,t3), tab_spanner = c("**Model 1**", "**Model 2**", "**Model 3**")) |>
  as_gt() |>
  tab_footnote(footnote = "Univariate", locations = cells_column_spanners("**Model 1**")) |>
  tab_footnote(footnote = "Univariate + Disease", locations = cells_column_spanners("**Model 2**")) |>
  tab_footnote(footnote = "Multivariate", locations = cells_column_spanners("**Model 3**")) |>
  tab_options(footnotes.multiline = FALSE) |>
  opt_footnote_marks(marks = "letters")

tf <- tempfile("example", fileext = ".docx")
tt %>% as_gt() %>% gt::gtsave(filename = tf)

# Deceased
t1 = tbl_uvregression(
  cryoadf %>% select(Disease, region3, age, marriage3, n_children, n_stored, 
                     sperm_seen, n_straws, n_fu, DAYS.deceased, Deceased),
  method = coxph,
  y = Surv(DAYS.deceased/365.25,Deceased),
  exponentiate = TRUE
) %>%
  add_global_p() %>% 
  bold_p() %>%
  bold_labels() %>% 
  italicize_levels() %>%
  add_n(location = "level") %>%
  add_nevent(location = "level") 

mdl2 <- function(var) {
  fit <- coxph(Surv(DAYS.deceased/365.25,Deceased) ~ 
                 Disease + var, data = cryoadf)
  tbl_regression(fit, exponentiate = TRUE) %>% 
    add_global_p() %>% 
    bold_p() %>%
    add_n(location = "level") %>%
    add_nevent(location = "level") %>%
    remove_row_type(Disease, type = "all")
}
a1 = mdl2(cryoadf$region3)
a2 = mdl2(cryoadf$age)
a3 = mdl2(cryoadf$marriage3)
a4 = mdl2(cryoadf$n_children)
a5 = mdl2(cryoadf$n_stored)
a6 = mdl2(cryoadf$sperm_seen)
a7 = mdl2(cryoadf$n_straws)
a8 = mdl2(cryoadf$n_fu)
a1$table_body$variable <- rep("region3",length(a1$table_body$variable))
a2$table_body$variable <- rep("age",length(a2$table_body$variable))
a3$table_body$variable <- rep("marriage3",length(a3$table_body$variable))
a4$table_body$variable <- rep("n_children",length(a4$table_body$variable))
a5$table_body$variable <- rep("n_stored",length(a5$table_body$variable))
a6$table_body$variable <- rep("sperm_seen",length(a6$table_body$variable))
a7$table_body$variable <- rep("n_straws",length(a7$table_body$variable))
a8$table_body$variable <- rep("n_fu",length(a8$table_body$variable))
t2 = tbl_stack(list(a1,a2,a3,a4,a5,a6,a7,a8))

fit.Deceased <- coxph(Surv(DAYS.deceased/365.25,Deceased) ~ 
                        Disease + region3 + age + marriage3 + n_children + n_stored + 
                        sperm_seen + n_straws + n_fu, data = cryoadf)
t3 = tbl_regression(fit.Deceased, exponentiate = TRUE) %>% 
  add_global_p() %>% 
  bold_p() %>%
  add_n(location = "level") %>%
  add_nevent(location = "level")

tt = tbl_merge(list(t1,t2,t3), tab_spanner = c("**Univariate**", "**Univariate + Disease**", "**Multivariate**")) %>%
  modify_caption("**Table 2. Death**")

tf <- tempfile("example", fileext = ".docx")
tt %>% as_gt() %>% gt::gtsave(filename = tf)

# Discarded
t1 = tbl_uvregression(
  cryoadf %>% select(Disease, region3, age, marriage3, n_children, n_stored, 
                     sperm_seen, n_straws, n_fu, DAYS.discarded, Discarded),
  method = coxph,
  y = Surv(DAYS.discarded/365.25,Discarded),
  exponentiate = TRUE
) %>%
  add_global_p() %>% 
  bold_p() %>%
  bold_labels() %>% 
  italicize_levels() %>%
  add_n(location = "level") %>%
  add_nevent(location = "level") 

mdl2 <- function(var) {
  fit <- coxph(Surv(DAYS.discarded/365.25,Discarded) ~ 
                 Disease + var, data = cryoadf)
  tbl_regression(fit, exponentiate = TRUE) %>% 
    add_global_p() %>% 
    bold_p() %>%
    add_n(location = "level") %>%
    add_nevent(location = "level") %>%
    remove_row_type(Disease, type = "all")
}
a1 = mdl2(cryoadf$region3)
a2 = mdl2(cryoadf$age)
a3 = mdl2(cryoadf$marriage3)
a4 = mdl2(cryoadf$n_children)
a5 = mdl2(cryoadf$n_stored)
a6 = mdl2(cryoadf$sperm_seen)
a7 = mdl2(cryoadf$n_straws)
a8 = mdl2(cryoadf$n_fu)
a1$table_body$variable <- rep("region3",length(a1$table_body$variable))
a2$table_body$variable <- rep("age",length(a2$table_body$variable))
a3$table_body$variable <- rep("marriage3",length(a3$table_body$variable))
a4$table_body$variable <- rep("n_children",length(a4$table_body$variable))
a5$table_body$variable <- rep("n_stored",length(a5$table_body$variable))
a6$table_body$variable <- rep("sperm_seen",length(a6$table_body$variable))
a7$table_body$variable <- rep("n_straws",length(a7$table_body$variable))
a8$table_body$variable <- rep("n_fu",length(a8$table_body$variable))
t2 = tbl_stack(list(a1,a2,a3,a4,a5,a6,a7,a8))

fit.Discarded <- coxph(Surv(DAYS.discarded/365.25,Discarded) ~ 
                        Disease + region3 + age + marriage3 + n_children + n_stored + 
                        sperm_seen + n_straws + n_fu, data = cryoadf)
t3 = tbl_regression(fit.Discarded, exponentiate = TRUE) %>% 
  add_global_p() %>% 
  bold_p() %>%
  add_n(location = "level") %>%
  add_nevent(location = "level")

tt = tbl_merge(list(t1,t2,t3), tab_spanner = c("**Univariate**", "**Univariate + Disease**", "**Multivariate**")) %>%
  modify_caption("**Table 3. Discarded**")

tf <- tempfile("example", fileext = ".docx")
tt %>% as_gt() %>% gt::gtsave(filename = tf)

# --------------------------

# KM plot: 20240603 --------

# combine 3 plots
fit.transfer <- survfit(Surv(days.transferred/365.25,Transfer) ~ 1, data = cryoadf)
fit.deceased <- survfit(Surv(days.deceased/365.25,Deceased) ~ 1, data = cryoadf)
fit.discarded <- survfit(Surv(days.discarded/365.25,Discarded) ~ 1, data = cryoadf)

quantile(fit.transfer, probs = c(0.25, 0.5, 0.75, 0.9))$quantile -> transfer # 1.0 2.4312115 6.0 10.5
quantile(fit.deceased, probs = c(0.25, 0.5, 0.75, 0.9))$quantile -> deceased # 0.9 1.6591376 3.3 6.0
quantile(fit.discarded, probs = c(0.25, 0.5, 0.75, 0.9))$quantile -> discarded # 4.8 7.690623 11.1 15.3
time <- rbind(transfer,deceased,discarded)
colnames(time) <- c("25% to outcome","50% to outcome","75% to outcome","90% to outcome")
rownames(time) <- NULL

library("survminer")

ggsurv3com <- function(fit,data,title) {
  ggsurvplot_combine(fit, data, 
                     break.time.by = 3, 
                     cumevents = TRUE,
                     xlab = "Time (years)",
                     xlim = c(0,30),
                     legend = c(0.35,0.75),
                     legend.title = "Time to outcomes",
                     legend.labs = c("Transfer", "Death", "Discarded"),
                     title = title,
                     font.main = c(16, "bold", "black"),
                     font.tickslab = c(12, "plain", "black"),
                     conf.int = TRUE, 
                     tables.col = "strata",
                     tables.height = 0.15,
                     tables.theme = theme_cleantable(),
                     ggtheme = theme_light(),
                     size = 1,
                     conf.int.style = "step"
  ) 
}
ggsurv3com.cum <- function(fit,data,title) {
  ggsurvplot_combine(fit, data, fun = "event",
                     break.time.by = 3, 
                     cumevents = TRUE,
                     xlab = "Time (years)",
                     xlim = c(0,30),
                     legend = c(0.35,0.75),
                     legend.title = "Time to outcomes",
                     legend.labs = c("Transfer", "Death", "Discarded"),
                     title = title,
                     font.main = c(16, "bold", "black"),
                     font.tickslab = c(12, "plain", "black"),
                     conf.int = TRUE, 
                     tables.col = "strata",
                     tables.height = 0.15,
                     tables.theme = theme_cleantable(),
                     ggtheme = theme_light(),
                     size = 1,
                     conf.int.style = "step"
  ) 
} # cumulative incidence

fit <- list(Transfer=fit.transfer, Deceased=fit.deceased, Discarded=fit.discarded)
ggsurv3com(fit,cryoadf,"Time to Transfer, Death and Discarded") -> ggsurv
ggsurv3com.cum(fit,cryoadf,"Time to Transfer, Death and Discarded") -> ggsurv
ggsurv$plot <- ggsurv$plot + 
  theme(legend.position = c(.4,.45),
        legend.key.size = unit(1.45, 'lines'),
        legend.spacing.y = unit(0.2,"cm"),
        legend.title = element_text(size = 13, color = "black", face = "bold"),
        legend.text = element_text(size = 12, color = "black", face = "plain"),
        axis.text.x = element_text(size = 13, color = "black", face = "bold"),
        axis.text.y = element_text(size = 13, color = "black", face = "bold"),
        axis.title.x = element_text(size = 13, color = "black", face = "bold"),
        axis.title.y = element_text(size = 13, color = "black", face = "bold")) +
  geom_segment(aes(x = 0, y = 0.5, xend = 7.690623, yend = 0.5), linetype="dashed") +
  geom_segment(aes(x = 7.690623, y = 0, xend = 7.690623, yend = 0.5), linetype="dashed") +
  geom_segment(aes(x = 1.6591376, y = 0, xend = 1.6591376, yend = 0.5), linetype="dashed") +
  geom_segment(aes(x = 2.4312115, y = 0, xend = 2.4312115, yend = 0.5), linetype="dashed") +
  annotation_custom(gridExtra::tableGrob(format(round(time, 1), nsmall=1)), 
                    xmin=14, xmax=31, ymin=0.4, ymax=0.5)
ggsurv
ggsave(filename = "Fig1", device='tiff', dpi=600) # only save the cum table
png("Fig1.jpeg", res=600, width=12050, height=7000)
print(ggsurv)
dev.off()

# by Disease
fit.transfer <- survfit(Surv(days.transferred/365.25,Transfer) ~ Disease, data = cryoadf)
fit.deceased <- survfit(Surv(days.deceased/365.25,Deceased) ~ Disease, data = cryoadf)
fit.discarded <- survfit(Surv(days.discarded/365.25,Discarded) ~ Disease, data = cryoadf)

quantile(fit.transfer, probs = c(0.25, 0.5, 0.75, 0.9))$quantile -> transfer
quantile(fit.deceased, probs = c(0.25, 0.5, 0.75, 0.9))$quantile -> deceased
quantile(fit.discarded, probs = c(0.25, 0.5, 0.75, 0.9))$quantile -> discarded
colnames(transfer) <- c("25% to transfer","50% to transfer","75% to transfer","90% to transfer")
colnames(deceased) <- c("25% to death","50% to death","75% to death","90% to death")
colnames(discarded) <- c("25% to discarded","50% to discarded","75% to discarded","90% to discarded")
rownames(transfer) <- NULL
rownames(deceased) <- NULL
rownames(discarded) <- NULL

ggsurv.Dia <- function(fit,data,title) {
  ggsurvplot(fit, data, fun="event",
             break.time.by = 3, 
             pval = TRUE,
             pval.coord = c(15,0.7),
             xlab = "Time (years)",
             title = title,
             font.main = c(16, "bold", "black"),
             surv.median.line = "hv",
             legend = c(0.4,0.75),
             legend.title = "Time to outcomes",
             legend.labs = c("Testis cancer","Lymphoma","Leukemia","Sarcoma",
                             "Colorectal cancer","Brain cancer","Other cancer","Non cancer"),
             ggtheme = theme_light(),
             size = 1
  ) 
}

ggsurv.Dia(fit.transfer,cryoadf,"Time to Transfer: by Disease") -> ggsurv.transfer
ggsurv$plot <- ggsurv$plot + 
  theme(legend.position = c(0.4,0.35),
        legend.key.size = unit(1.45, 'lines'),
        legend.spacing.y = unit(0.2,"cm"),
        legend.title = element_text(size = 14, color = "black", face = "bold"),
        legend.text = element_text(size = 13, color = "black", face = "plain"),
        axis.text.x = element_text(size = 13, color = "black", face = "bold"),
        axis.text.y = element_text(size = 13, color = "black", face = "bold"),
        axis.title.x = element_text(size = 13, color = "black", face = "bold"),
        axis.title.y = element_text(size = 13, color = "black", face = "bold")) +
  annotation_custom(gridExtra::tableGrob(format(round(transfer, 1), nsmall=1)), 
                    xmin=12, xmax=24, ymin=0.3, ymax=0.37) 
ggsurv.transfer

ggsurv.Dia30 <- function(fit,data,title) {
  ggsurvplot(fit, data, fun="event",
             break.time.by = 3, 
             pval = TRUE,
             pval.coord = c(15,0.7),
             xlab = "Time (years)",
             xlim = c(0,30),
             title = title,
             font.main = c(16, "bold", "black"),
             surv.median.line = "hv",
             legend = c(0.4,0.75),
             legend.title = "Time to outcomes",
             legend.labs = c("Testis cancer","Lymphoma","Leukemia","Sarcoma",
                             "Colorectal cancer","Brain cancer","Other cancer","Non cancer"),
             ggtheme = theme_light(),
             size = 1
  ) 
}

ggsurv.Dia30(fit.deceased,cryoadf,"Time to Death: by Disease") -> ggsurv.deceased
ggsurv$plot <- ggsurv$plot + 
  theme(legend.position = c(0.4,0.35),
        legend.key.size = unit(1.45, 'lines'),
        legend.spacing.y = unit(0.2,"cm"),
        legend.title = element_text(size = 14, color = "black", face = "bold"),
        legend.text = element_text(size = 13, color = "black", face = "plain"),
        axis.text.x = element_text(size = 13, color = "black", face = "bold"),
        axis.text.y = element_text(size = 13, color = "black", face = "bold"),
        axis.title.x = element_text(size = 13, color = "black", face = "bold"),
        axis.title.y = element_text(size = 13, color = "black", face = "bold")) +
  annotation_custom(gridExtra::tableGrob(format(round(deceased, 1), nsmall=1)), 
                    xmin=15, xmax=27, ymin=0.3, ymax=0.37)
ggsurv.deceased

ggsurv.Dia30(fit.discarded,cryoadf,"Time to Discarded: by Disease") -> ggsurv.discarded
ggsurv$plot <- ggsurv$plot + 
  theme(legend.position = c(0.415,0.33),
        legend.key.size = unit(1.45, 'lines'),
        legend.spacing.y = unit(0.2,"cm"),
        legend.title = element_text(size = 14, color = "black", face = "bold"),
        legend.text = element_text(size = 13, color = "black", face = "plain"),
        axis.text.x = element_text(size = 13, color = "black", face = "bold"),
        axis.text.y = element_text(size = 13, color = "black", face = "bold"),
        axis.title.x = element_text(size = 13, color = "black", face = "bold"),
        axis.title.y = element_text(size = 13, color = "black", face = "bold")) +
  annotation_custom(gridExtra::tableGrob(format(round(discarded, 1), nsmall=1)), 
                    xmin=16, xmax=30, ymin=0.25, ymax=0.37)
ggsurv.discarded

# add overall cumevent number to 3 plots
fit.all <- survfit(Surv(days.transferred/365.25,Transfer) ~ 1, data = cryoadf)
ggsurv.all <- ggsurvplot(fit.all, cryoadf, legend = "none", break.time.by = 3, legend.labs = "",
                         cumevents = TRUE, xlab = "Time (years)", xlim = c(0,30),
                         tables.height = 0.15, ggtheme = theme_light())
ggsurv.all$plot + theme(legend.title=element_blank()) 
ggsurv.all[["cumevents"]][["labels"]][["y"]] <- NULL
ggsurv.all[["cumevents"]][["labels"]][["x"]] <- NULL
ggsurv.all$cumevents -> all

img1 <- readPNG("transfer.png")
img2 <- readPNG("transfer.num.png")
grid.arrange(rasterGrob(img1),rasterGrob(img2),ncol=1)

grid.arrange(rasterGrob(plot1),rasterGrob(plot2),ncol=1)
ggsurv.Dia(fit.deceased,cryoadf,"Time to Deceased: by Disease") -> ggsurv


# --------------------------

# COX model: 20240604 -----

fit.Transfer <- coxph(Surv(DAYS.transferred/365.25,Transfer) ~ 
                        Disease + region3 + age + marriage3 + n_children + n_stored + 
                        n_straws + n_fu + sperm_seen2, data = cryoadf)
transfer = tbl_regression(fit.Transfer, exponentiate = TRUE) %>% 
  add_global_p() %>% bold_p()

fit.Deceased <- coxph(Surv(DAYS.deceased/365.25,Deceased) ~ 
                        Disease + region3 + age + marriage3 + n_children + n_stored + 
                        n_straws + n_fu + sperm_seen2, data = cryoadf)
deceased = tbl_regression(fit.Deceased, exponentiate = TRUE) %>% 
  add_global_p() %>% bold_p()

fit.Discarded <- coxph(Surv(DAYS.discarded/365.25,Discarded) ~ 
                        Disease + region3 + age + marriage3 + n_children + n_stored + 
                        n_straws + n_fu + sperm_seen2, data = cryoadf)
discarded = tbl_regression(fit.Discarded, exponentiate = TRUE) %>% 
  add_global_p() %>% bold_p()

tt = tbl_merge(list(transfer, deceased, discarded), tab_spanner = c("**Time to Transfer**", "**Time to Death**", "**Time to Discard**")) %>%
  modify_caption("**Table 2 Summary of Multivariate Cox Model Regression**")
# tt %>% modify_caption("**Table 1. Patient Characteristics**")
tt %>% as_gt() %>% gt::gtsave(filename = "Table2.docx") # no title, internal lines linked

# sperm seen opposite direction
t1 <- tbl_cross(cryoadf, sperm_seen, Transfer, percent="cell", missing="no")
t2 <- tbl_cross(cryoadf, sperm_seen, Deceased, percent="cell", missing="no")
t3 <- tbl_cross(cryoadf, sperm_seen, Discarded, percent="cell", missing="no")
tbl_merge(list(t1,t2,t3), tab_spanner = c("Transfer","Deceased","Discarded"))

# --------------------------

# KM plot: 20240604 --------

# transfer
fit.transfer <- survfit(Surv(days.transferred/365.25,Transfer) ~ 1, data = cryoadf)
ggsurvplot(fit.transfer, cryoadf, fun="event",
           break.time.by = 3, 
           cumevents = TRUE,
           conf.int = FALSE,
           palette = "white",
           xlab = "Time (years)",
           font.main = c(16, "bold", "black"),
           legend = "none",
           legend.title = "All",
           tables.height = 0.2,
           ggtheme = theme_light(),
           size = 1
) -> ove
fit.transfer.dis <- survfit(Surv(days.transferred/365.25,Transfer) ~ Disease, data = cryoadf)
ggsurvplot(fit.transfer.dis, cryoadf, fun="event",
           title = "Time to Transfer: by Disease",
           break.time.by = 3, 
           cumevents = TRUE,
           pval = TRUE,
           pval.coord = c(15,0.7),
           xlab = "Time (years)",
           font.main = c(16, "bold", "black"),
           surv.median.line = "hv",
           legend = c(0.4,0.35),
           legend.title = "Time to outcomes",
           legend.labs = c("Testis cancer","Lymphoma","Leukemia","Sarcoma",
                           "Colorectal cancer","Brain cancer","Other cancer","Non cancer"),
           ggtheme = theme_light(),
           tables.theme = theme_cleantable(),
           tables.height = 0.15,
           size = 1
) -> dis
dis$cumevents <- ove$cumevents;dis$cumevents$labels$x <- ""
dis$plot <- dis$plot + 
  theme(legend.position.inside = c(0.415,0.33),
        legend.key.size = unit(1.4, 'lines'),
        legend.spacing.y = unit(0.2,"cm"),
        legend.title = element_text(size = 14, color = "black", face = "bold"),
        legend.text = element_text(size = 12, color = "black", face = "plain"),
        axis.text.x = element_text(size = 13, color = "black", face = "bold"),
        axis.text.y = element_text(size = 13, color = "black", face = "bold"),
        axis.title.x = element_text(size = 13, color = "black", face = "bold"),
        axis.title.y = element_text(size = 13, color = "black", face = "bold")) +
  annotation_custom(gridExtra::tableGrob(format(round(transfer, 1), nsmall=1)), 
                    xmin=13, xmax=25, ymin=0.25, ymax=0.37)
dis # png size 1160 690

# deceased
fit.deceased <- survfit(Surv(days.deceased/365.25,Deceased) ~ 1, data = cryoadf)
ggsurvplot(fit.deceased, cryoadf, fun="event",
           break.time.by = 3, 
           cumevents = TRUE,
           conf.int = FALSE,
           palette = "white",
           xlab = "Time (years)",
           xlim = c(0,30),
           font.main = c(16, "bold", "black"),
           legend = "none",
           legend.title = "All",
           tables.height = 0.2,
           ggtheme = theme_light(),
           size = 1
) -> ove
fit.deceased.dis <- survfit(Surv(days.deceased/365.25,Deceased) ~ Disease, data = cryoadf)
ggsurvplot(fit.deceased.dis, cryoadf, fun="event",
           title = "Time to Death: by Disease",
           break.time.by = 3, 
           cumevents = TRUE,
           pval = TRUE,
           pval.coord = c(15,0.7),
           xlab = "Time (years)",
           xlim = c(0,30),
           font.main = c(16, "bold", "black"),
           surv.median.line = "hv",
           legend = c(0.4,0.35),
           legend.title = "Time to outcomes",
           legend.labs = c("Testis cancer","Lymphoma","Leukemia","Sarcoma",
                           "Colorectal cancer","Brain cancer","Other cancer","Non cancer"),
           ggtheme = theme_light(),
           tables.theme = theme_cleantable(),
           tables.height = 0.15,
           size = 1
) -> dis
dis$cumevents <- ove$cumevents;dis$cumevents$labels$x <- ""
dis$plot <- dis$plot + 
  theme(legend.position.inside = c(0.415,0.33),
        legend.key.size = unit(1.4, 'lines'),
        legend.spacing.y = unit(0.2,"cm"),
        legend.title = element_text(size = 14, color = "black", face = "bold"),
        legend.text = element_text(size = 12, color = "black", face = "plain"),
        axis.text.x = element_text(size = 13, color = "black", face = "bold"),
        axis.text.y = element_text(size = 13, color = "black", face = "bold"),
        axis.title.x = element_text(size = 13, color = "black", face = "bold"),
        axis.title.y = element_text(size = 13, color = "black", face = "bold")) +
  annotation_custom(gridExtra::tableGrob(format(round(deceased, 1), nsmall=1)), 
                    xmin=15, xmax=28.5, ymin=0.25, ymax=0.37)
dis # png size 1160 690

# discarded
fit.discarded <- survfit(Surv(days.discarded/365.25,Discarded) ~ 1, data = cryoadf)
ggsurvplot(fit.discarded, cryoadf, fun="event",
           break.time.by = 3, 
           cumevents = TRUE,
           conf.int = FALSE,
           palette = "white",
           xlab = "Time (years)",
           xlim = c(0,30),
           font.main = c(16, "bold", "black"),
           legend = "none",
           legend.title = "All",
           tables.height = 0.2,
           ggtheme = theme_light(),
           size = 1
) -> ove
fit.discarded.dis <- survfit(Surv(days.discarded/365.25,Discarded) ~ Disease, data = cryoadf)
ggsurvplot(fit.discarded.dis, cryoadf, fun="event",
           title = "Time to Discarded: by Disease",
           break.time.by = 3, 
           cumevents = TRUE,
           pval = TRUE,
           pval.coord = c(15,0.7),
           xlab = "Time (years)",
           xlim = c(0,30),
           font.main = c(16, "bold", "black"),
           surv.median.line = "hv",
           legend = c(0.4,0.35),
           legend.title = "Time to outcomes",
           legend.labs = c("Testis cancer","Lymphoma","Leukemia","Sarcoma",
                           "Colorectal cancer","Brain cancer","Other cancer","Non cancer"),
           ggtheme = theme_light(),
           tables.theme = theme_cleantable(),
           tables.height = 0.15,
           size = 1
) -> dis
dis$cumevents <- ove$cumevents;dis$cumevents$labels$x <- ""
dis$plot <- dis$plot + 
  theme(legend.position.inside = c(0.4,0.3),
        legend.key.size = unit(1.4, 'lines'),
        legend.spacing.y = unit(0.2,"cm"),
        legend.title = element_text(size = 14, color = "black", face = "bold"),
        legend.text = element_text(size = 12, color = "black", face = "plain"),
        axis.text.x = element_text(size = 13, color = "black", face = "bold"),
        axis.text.y = element_text(size = 13, color = "black", face = "bold"),
        axis.title.x = element_text(size = 13, color = "black", face = "bold"),
        axis.title.y = element_text(size = 13, color = "black", face = "bold")) +
  annotation_custom(gridExtra::tableGrob(format(round(discarded, 1), nsmall=1)), 
                    xmin=15, xmax=30, ymin=0.21, ymax=0.35)
dis # png size 1230 790

# --------------------------

# gtsummary application: 20240605 -------

# try to export table to OFFICE properly
tt %>% as_hux_xlsx("Table2.xlsx") # huxtable and openxlsx library
tt |> gtsummary::as_flex_table() |> 
  flextable::set_caption(
    flextable::as_paragraph(
      flextable::as_chunk("Table 1 Invertebrate Speciation \n (Australia)", italic=TRUE, bold=TRUE)
    ), 
    word_stylename = "Table Caption") |> 
  flextable::save_as_docx(path = "T001 IS - AUS.docx") # flextable and not italic, not bold

# Appending multiple gt_summary tables in same word doc
tt %>%
  as_gt()%>%
  gt::gtsave("tmp2.docx") # Store second table as separate Word document
library(officer)
doc1 <- read_docx("T001 IS - AUS.docx") # Read in first table document as an R object
print(
  body_add_docx(doc1, src = "tmp2.docx", pos = "after"),
  target = "FinalTable.docx"
) # Add content of second table docx to the object

# Add multiple levels of headers to gtsummary regression table with many models
library(dplyr)
library(gtsummary)
library(purrr)
set.seed(92922)
df <- tibble(y_1980 = rbinom(n = 10, size = 1, prob = .4),
             y_1990 = rbinom(n = 10, size = 1, prob = .7),
             x1 = rnorm(10, sd = 1),
             x2 = rnorm(10, sd = 2))
tbls <- c("y_1980 ~ x1", "y_1980 ~ x1 + x2", "y_1990 ~ x1", "y_1990 ~ x1 + x2") %>% 
  map(as.formula) %>% 
  map(glm,
      data = df, 
      family = binomial(link = "logit")) %>% 
  map(tbl_regression, exponentiate = TRUE) %>% 
  map(add_significance_stars, hide_ci = TRUE, hide_p = TRUE, hide_se = FALSE) %>% 
  map(add_glance_table, include = nobs) 
tbl <-
  tbls %>% 
  tbl_merge(tab_spanner = FALSE) %>% 
  modify_table_body(~.x %>% dplyr::arrange(row_type == "glance_statistic"))
show_header_names(tbl)
gt_tbl <- 
  as_gt(tbl) %>%
  gt::tab_spanner(
    columns = c(estimate_1, std.error_1, estimate_3, std.error_3),
    label = "(1)",
    gather = FALSE
  ) %>%
  gt::tab_spanner(
    columns = c(estimate_2, std.error_2, estimate_4, std.error_4),
    label = "(2)",
    gather = FALSE
  ) %>%
  gt::tab_spanner(
    columns = c(estimate_1, std.error_1, estimate_2, std.error_2),
    label = "1980",
    level = 2,
    gather = FALSE
  ) %>%
  gt::tab_spanner(
    columns = c(estimate_3, std.error_3, estimate_4, std.error_4),
    label = "1990",
    level = 2,
    gather = FALSE
  ) 

# Adding strata to tables
library(gtsummary)
library(tidyverse)
theme_gtsummary_compact() # make compact tables
tbls <-
  # nest variables by stratification variable `bdy_style`
  gt::gtcars  %>%
  select(bdy_style, drivetrain, msrp) %>%
  mutate(drivetrain = factor(drivetrain)) %>%
  group_nest(bdy_style) %>% # build tbls separately by `bdy_style`
  rowwise() %>%
  mutate(
    tbl = tbl_summary(data, by = drivetrain, type = everything() ~ "continuous") %>% list()
  ) # a list var "tbl" in tibble
tbl_merge(tbls$tbl, tab_spanner = str_glue("**{tbls$bdy_style}**"))
# nest_by
out <-  df %>%
  select(-id) %>% 
  pivot_longer(cols = starts_with('cond'), 
               names_to = 'condition', values_to = 'case') %>% 
  nest_by(condition) %>% 
  mutate(model = list(glm(case ~ gender + age + 
                            race + health_score, 
                          family = "binomial", data = data)), 
         table_out = list(tbl_regression(model, exponentiate = TRUE, conf.level = 0.99)))
tbl_merge(out$table_out)

# Stratified gtsummary tables
trial %>%
  select(age, grade, stage, trt) %>%
  mutate(grade = paste("Grade", grade)) %>%
  tbl_strata( 
    strata = grade,
    .tbl_fun =
      ~ .x %>%
      tbl_summary(by = trt, missing = "no") %>%
      add_n(),
    .header = "**{strata}**, N = {n}"
  )
trial %>%
  select(grade, response) %>%
  mutate(grade = paste("Grade", grade)) %>%
  tbl_strata2(
    strata = grade,
    .tbl_fun =
      ~ .x %>%
      tbl_summary(
        label = list(response = .y),
        missing = "no",
        statistic = response ~ "{p}%"
      ) %>%
      add_ci(pattern = "{stat} ({ci})") %>%
      modify_header(stat_0 = "**Rate (95% CI)**") %>%
      modify_footnote(stat_0 = NA),
    .combine_with = "tbl_stack",
    .combine_args = list(group_header = NULL),
    .quiet = TRUE
  ) %>%
  modify_caption("**Response Rate by Grade**")

# multiple regression models
tbl <- 
  c("cyl", "cyl + disp") %>%            # vector of covariates
  map(
    ~ paste("mpg", .x, sep = " ~ ") %>% # build character formula
      as.formula() %>%                  # convert to proper formula
      lm(data = mtcars) %>%             # build linear regression model
      tbl_regression()                  # display table with gtsummary
  ) %>%
  tbl_merge( # merge tables into single table
    tab_spanner = c("**Univariate**", "**Multivariable**")
  )

# --------------------------

# tab spanner: 20240605 -------

t1 <- tbl_uvregression(
  cryoadf %>% select(Disease, region3, age, marriage3, n_children, n_stored, n_straws, 
                     n_fu, sperm_seen2, DAYS.transferred, Transfer),
  hide_n = TRUE,
  method = coxph,
  y = Surv(DAYS.transferred/365.25,Transfer),
  exponentiate = TRUE
) %>%
  add_global_p() %>% bold_p() %>% bold_labels() %>% italicize_levels()
t2 <- tbl_uvregression(
  cryoadf %>% select(Disease, region3, age, marriage3, n_children, n_stored, n_straws, 
                     n_fu, sperm_seen2, DAYS.deceased, Deceased),
  hide_n = TRUE,
  method = coxph,
  y = Surv(DAYS.deceased/365.25,Deceased),
  exponentiate = TRUE
) %>%
  add_global_p() %>% bold_p() %>% bold_labels() %>% italicize_levels()
t3 <- tbl_uvregression(
  cryoadf %>% select(Disease, region3, age, marriage3, n_children, n_stored, n_straws, 
                     n_fu, sperm_seen2, DAYS.discarded, Discarded),
  hide_n = TRUE,
  method = coxph,
  y = Surv(DAYS.discarded/365.25,Discarded),
  exponentiate = TRUE
) %>%
  add_global_p() %>% bold_p() %>% bold_labels() %>% italicize_levels()

fit.Transfer <- coxph(Surv(DAYS.transferred/365.25,Transfer) ~ 
                        Disease + region3 + age + marriage3 + n_children + n_stored + 
                        n_straws + n_fu + sperm_seen2, data = cryoadf)
t4 <- tbl_regression(fit.Transfer, exponentiate = TRUE) %>% 
  add_global_p() %>% bold_p()
fit.Deceased <- coxph(Surv(DAYS.deceased/365.25,Deceased) ~ 
                        Disease + region3 + age + marriage3 + n_children + n_stored + 
                        n_straws + n_fu + sperm_seen2, data = cryoadf)
t5 <- tbl_regression(fit.Deceased, exponentiate = TRUE) %>% 
  add_global_p() %>% bold_p()
fit.Discarded <- coxph(Surv(DAYS.discarded/365.25,Discarded) ~ 
                         Disease + region3 + age + marriage3 + n_children + n_stored + 
                        n_straws + n_fu + sperm_seen2, data = cryoadf)
t6 <- tbl_regression(fit.Discarded, exponentiate = TRUE) %>% 
  add_global_p() %>% bold_p()
tbl <- 
  tbl_merge(list(t1,t4,t2,t5,t3,t6), 
            tab_spanner = rep(c("**Univariate**","**Multivariate**"),3)) %>% 
  modify_caption("**Table 2 Summary of Cox Model Regression**")
show_header_names(tbl) # show columns names
tbl |> as_gt() |>
  tab_spanner(
    label = gt::md("**Transfer**"),
    columns = c(estimate_1,ci_1,p.value_1,estimate_2,ci_2,p.value_2),
    level = 2
    ) |>
  tab_spanner(
    label = gt::md("**Death**"),
    columns = c(estimate_3,ci_3,p.value_3,estimate_4,ci_4,p.value_4),
    level = 2
  ) |>
  tab_spanner(
    label = gt::md("**Discarded**"),
    columns = c(estimate_5,ci_5,p.value_5,estimate_6,ci_6,p.value_6),
    level = 2
  ) 
tbl %>% as_gt() %>% gt::gtsave(filename = "spanner.docx") # no level 2 spanner
tbl %>% as_hux_xlsx("spanner.xlsx") # huxtable and openxlsx library, no level 2 spanner
# use RMarkdown to save properly formatted Word, without title, internal lines linked

# --------------------------

# lasso: 20240605 ------
# Lasso Regression shines when dealing with datasets containing numerous variables, 
# many of which may not be relevant or have a weak impact on the target variable. 
# By shrinking some coefficient estimates to zero, Lasso automatically performs 
# feature selection, simplifying your model and improving its interpretability.

library(glmnet)
lasso <- cryoadf %>% 
  select(Transfer, DAYS.transferred,
         Disease, region3, age, marriage3, n_children, n_stored, n_straws, n_fu, sperm_seen2) %>%
  na.omit()
x = lasso %>% 
  select(-c(Transfer, DAYS.transferred))
x1 = makeX(x)
y = Surv(lasso$DAYS.transferred,lasso$Transfer)
fit <- glmnet(x1, y, family = "cox")
plot(fit)
coef(fit, s=0.01)
cvfit <- cv.glmnet(x1, y, family = "cox")
cvfit$lambda.min;cvfit$lambda.1se
plot(cvfit)
coef(cvfit, s = "lambda.min")
                   
# --------------------------

# KM plot poster: 20241030 --------

## combine 3 plots
fit.transfer <- survfit(Surv(days.transferred/365.25,Transfer) ~ 1, data = cryoadf)
fit.deceased <- survfit(Surv(days.deceased/365.25,Deceased) ~ 1, data = cryoadf)
fit.discarded <- survfit(Surv(days.discarded/365.25,Discarded) ~ 1, data = cryoadf)

quantile(fit.transfer, probs = c(0.25, 0.5, 0.75, 0.9))$quantile -> transfer # 1.0 2.4312115 6.0 10.5
quantile(fit.deceased, probs = c(0.25, 0.5, 0.75, 0.9))$quantile -> deceased # 0.9 1.6591376 3.3 6.0
quantile(fit.discarded, probs = c(0.25, 0.5, 0.75, 0.9))$quantile -> discarded # 4.8 7.690623 11.1 15.3
time <- rbind(transfer,deceased,discarded)
colnames(time) <- c("25% to outcome","50% to outcome","75% to outcome","90% to outcome")
rownames(time) <- NULL

library("survminer")

ggsurv3com.cum <- function(fit,data,title) {
  ggsurvplot_combine(fit, data, fun = "event",
                     break.time.by = 3, 
                     cumevents = TRUE,
                     fontsize = 8, # number size for risk table and cumevent table, or cumevents.fontsize = 10
                     xlab = "Time (years)",
                     xlim = c(0,30),
                     title = title,
                     legend = c(0.35,0.75),
                     legend.title = "Time to outcomes",
                     legend.labs = c("Transfer", "Death", "Discarded"),
                     font.main = c(25, "bold", "black"), # title font
                     font.tickslab = c(18, "plain", "black"), # x- y-lab, table number font size
                     conf.int = TRUE, 
                     tables.col = "strata",
                     tables.height = 0.15,
                     tables.theme = theme_cleantable() + 
                       theme(text = element_text(size = 20, face = "bold"), # table title font size
                             axis.text.y = element_text(size = 20, face = "bold", # table strata name font size
                                                        margin = margin(t=0,r=0,b=0,l=-65))),
                     ggtheme = theme_light() +
                       theme(legend.title = element_text(size = 20, color = "black", face = "bold"),
                             legend.text = element_text(size = 19, color = "black", face = "plain"),
                             axis.text.x = element_text(size = 20, color = "black", face = "bold"),
                             axis.text.y = element_text(size = 20, color = "black", face = "bold"),
                             axis.title.x = element_text(size = 20, color = "black", face = "bold"),
                             axis.title.y = element_text(size = 20, color = "black", face = "bold",
                                                         margin = margin(t = 0, r = 15, b = 0, l = 30))),
                     size = 1,
                     conf.int.style = "step"
  ) 
} # cumulative incidence

fit <- list(Transfer=fit.transfer, Deceased=fit.deceased, Discarded=fit.discarded)
ggsurv3com.cum(fit,cryoadf,"Time to Transfer, Death and Discarded") -> ggsurv
ggsurv$plot <- ggsurv$plot + 
  theme(legend.position = c(.4,.475),
        legend.key.size = unit(2.5, 'lines'),
        legend.spacing.y = unit(0.2,"cm")
        ) +
  geom_segment(aes(x = 0, y = 0.5, xend = 7.690623, yend = 0.5), linetype="dashed") +
  geom_segment(aes(x = 7.690623, y = 0, xend = 7.690623, yend = 0.5), linetype="dashed") +
  geom_segment(aes(x = 1.6591376, y = 0, xend = 1.6591376, yend = 0.5), linetype="dashed") +
  geom_segment(aes(x = 2.4312115, y = 0, xend = 2.4312115, yend = 0.5), linetype="dashed")

# add time table 

library(grid)
library(gridExtra)

vp <- viewport(x = 0.7, y = 0.5, width = 0.3, height = 0.3) 
grid.rect(vp = vp) # grib table position on the white background
timetbl <- tableGrob(round(time, 1), vp = vp)
timetbl$widths <- rep(unit(1/ncol(timetbl),"null"), ncol(timetbl))
timetbl$heights <- rep(unit(1/nrow(timetbl), "null"), nrow(timetbl))
timetbl$grobs[[1]][["gp"]] <- gpar(fontsize=20, fontface="bold")
timetbl$grobs[[2]][["gp"]] <- gpar(fontsize=20, fontface="bold")
timetbl$grobs[[3]][["gp"]] <- gpar(fontsize=20, fontface="bold")
timetbl$grobs[[4]][["gp"]] <- gpar(fontsize=20, fontface="bold")
timetbl$grobs[[9]][["gp"]] <- gpar(fontsize=20, fontface="plain")
timetbl$grobs[[10]][["gp"]] <- gpar(fontsize=20, fontface="plain")
timetbl$grobs[[11]][["gp"]] <- gpar(fontsize=20, fontface="plain")
timetbl$grobs[[12]][["gp"]] <- gpar(fontsize=20, fontface="plain")
timetbl$grobs[[13]][["gp"]] <- gpar(fontsize=20, fontface="plain")
timetbl$grobs[[14]][["gp"]] <- gpar(fontsize=20, fontface="plain")
timetbl$grobs[[15]][["gp"]] <- gpar(fontsize=20, fontface="plain")
timetbl$grobs[[16]][["gp"]] <- gpar(fontsize=20, fontface="plain")
timetbl$grobs[[17]][["gp"]] <- gpar(fontsize=20, fontface="plain")
timetbl$grobs[[18]][["gp"]] <- gpar(fontsize=20, fontface="plain")
timetbl$grobs[[19]][["gp"]] <- gpar(fontsize=20, fontface="plain")
timetbl$grobs[[20]][["gp"]] <- gpar(fontsize=20, fontface="plain")
grid.newpage()
grid.draw(timetbl)

ggsurv$plot <- ggsurv$plot +
  annotation_custom(timetbl,xmin=13.97, xmax=31, ymin=0.35, ymax=0.6)
  #cowplot::draw_grob(gridExtra::tableGrob(round(time, 1), rows=NULL), x=22, y=.08, width=1, height=1, scale=.5)
ggsurv

png("Fig1.jpeg", res=600, width=12000, height=7000)
print(ggsurv)
dev.off()

## by Disease

# quantile time table by Disease
fit.transfer <- survfit(Surv(days.transferred/365.25,Transfer) ~ Disease, data = cryoadf)
fit.deceased <- survfit(Surv(days.deceased/365.25,Deceased) ~ Disease, data = cryoadf)
fit.discarded <- survfit(Surv(days.discarded/365.25,Discarded) ~ Disease, data = cryoadf)

quantile(fit.transfer, probs = c(0.25, 0.5, 0.75, 0.9))$quantile -> transfer
quantile(fit.deceased, probs = c(0.25, 0.5, 0.75, 0.9))$quantile -> deceased
quantile(fit.discarded, probs = c(0.25, 0.5, 0.75, 0.9))$quantile -> discarded
colnames(transfer) <- c("25% to transfer","50% to transfer","75% to transfer","90% to transfer")
colnames(deceased) <- c("25% to death","50% to death","75% to death","90% to death")
colnames(discarded) <- c("25% to discarded","50% to discarded","75% to discarded","90% to discarded")
rownames(transfer) <- NULL
rownames(deceased) <- NULL
rownames(discarded) <- NULL

## transfer
fit.transfer <- survfit(Surv(days.transferred/365.25,Transfer) ~ 1, data = cryoadf)
ggsurvplot(fit.transfer, cryoadf, fun="event",
           break.time.by = 3, 
           cumevents = TRUE,
           fontsize = 8, # cumevents table number fontsize
           conf.int = FALSE,
           palette = "white",
           xlab = "Time (years)",
           font.main = c(16, "bold", "black"),
           legend = "none",
           legend.title = "All",
           tables.height = 0.2,
           ggtheme = theme_light() + 
             theme(text = element_text(size = 20, face = "bold"), # table title font size
                   axis.text.y = element_text(size = 20, face = "bold", # table strata name font size
                                              margin = margin(t=0,r=0,b=0,l=10)),
                   axis.title.y = element_blank(),
                   axis.ticks.x = element_blank(),
                   axis.text.x = element_blank()),
           size = 1
) -> ove
fit.transfer.dis <- survfit(Surv(days.transferred/365.25,Transfer) ~ Disease, data = cryoadf)
ggsurvplot(fit.transfer.dis, cryoadf, fun="event",
           title = "Time to Transfer: by Disease",
           break.time.by = 3, 
           cumevents = TRUE,
           pval = TRUE,
           pval.coord = c(15,0.7),
           pval.size = 10,
           xlab = "Time (years)",
           font.main = c(25, "bold", "black"), # title font
           font.tickslab = c(18, "plain", "black"), # x- y-lab, table number font size
           surv.median.line = "hv",
           legend = c(0.4,0.35),
           legend.title = "Time to outcomes",
           legend.labs = c("Testis cancer","Lymphoma","Leukemia","Sarcoma",
                           "Colorectal cancer","Brain cancer","Other cancer","Non cancer"),
           ggtheme = theme_light() +
             theme(legend.title = element_text(size = 20, color = "black", face = "bold"),
                   legend.text = element_text(size = 19, color = "black", face = "plain"),
                   axis.text.x = element_text(size = 20, color = "black", face = "bold"),
                   axis.text.y = element_text(size = 20, color = "black", face = "bold"),
                   axis.title.x = element_text(size = 20, color = "black", face = "bold"),
                   axis.title.y = element_text(size = 20, color = "black", face = "bold",
                                               margin = margin(t = 0, r = 10, b = 0, l = 10))),
           tables.theme = theme_cleantable(),
           tables.height = 0.15,
           size = 1
) -> dis
dis$cumevents <- ove$cumevents;dis$cumevents$labels$x <- ""
dis$plot <- dis$plot + 
  theme(legend.position.inside = c(0.36,0.32),
        legend.key.size = unit(2.3, 'lines')) 
dis 

# add time table

library(grid)
library(gridExtra)

timetbl <- tableGrob(round(transfer, 1))
timetbl$widths <- rep(unit(1/ncol(timetbl),"null"), ncol(timetbl))
timetbl$heights <- rep(unit(1/nrow(timetbl), "null"), nrow(timetbl))
timetbl$grobs[[1]][["gp"]] <- gpar(fontsize=20, fontface="bold")
timetbl$grobs[[2]][["gp"]] <- gpar(fontsize=20, fontface="bold")
timetbl$grobs[[3]][["gp"]] <- gpar(fontsize=20, fontface="bold")
timetbl$grobs[[4]][["gp"]] <- gpar(fontsize=20, fontface="bold")
for (i in c(9:40)) {
  timetbl$grobs[[i]][["gp"]] <- gpar(fontsize = 20, fontface = "plain")
}
grid.newpage()
grid.draw(timetbl)

dis$plot <- dis$plot +
  annotation_custom(timetbl, xmin=10.65, xmax=25, ymin=0.05, ymax=0.57)
dis # png size 1160 690

png("Fig2.jpeg",width=12000,height=7000,res=600)
print(dis)
dev.off()

# deceased
fit.deceased <- survfit(Surv(days.deceased/365.25,Deceased) ~ 1, data = cryoadf)
ggsurvplot(fit.deceased, cryoadf, fun="event",
           break.time.by = 3, 
           cumevents = TRUE,
           fontsize = 8, # cumevents table number size
           conf.int = FALSE,
           palette = "white",
           xlab = "Time (years)",
           xlim = c(0,30),
           font.main = c(16, "bold", "black"),
           legend = "none",
           legend.title = "All",
           tables.height = 0.2,
           ggtheme = theme_light() + 
             theme(text = element_text(size = 20, face = "bold"), # table title font size
                   axis.text.y = element_text(size = 20, face = "bold", # table strata name font size
                                              margin = margin(t=0,r=0,b=0,l=10)),
                   axis.title.y = element_blank(),
                   axis.ticks.x = element_blank(),
                   axis.text.x = element_blank()),
           size = 1
) -> ove
fit.deceased.dis <- survfit(Surv(days.deceased/365.25,Deceased) ~ Disease, data = cryoadf)
ggsurvplot(fit.deceased.dis, cryoadf, fun="event",
           title = "Time to Death: by Disease",
           break.time.by = 3, 
           cumevents = TRUE,
           pval = TRUE,
           pval.coord = c(15,0.7),
           pval.size = 10,
           xlab = "Time (years)",
           xlim = c(0,30),
           font.main = c(25, "bold", "black"), # title font
           font.tickslab = c(18, "plain", "black"), # x- y-lab, table number font size
           surv.median.line = "hv",
           legend = c(0.4,0.35),
           legend.title = "Time to outcomes",
           legend.labs = c("Testis cancer","Lymphoma","Leukemia","Sarcoma",
                           "Colorectal cancer","Brain cancer","Other cancer","Non cancer"),
           ggtheme = theme_light() +
             theme(legend.title = element_text(size = 20, color = "black", face = "bold"),
                   legend.text = element_text(size = 19, color = "black", face = "plain"),
                   axis.text.x = element_text(size = 20, color = "black", face = "bold"),
                   axis.text.y = element_text(size = 20, color = "black", face = "bold"),
                   axis.title.x = element_text(size = 20, color = "black", face = "bold"),
                   axis.title.y = element_text(size = 20, color = "black", face = "bold",
                                               margin = margin(t = 0, r = 10, b = 0, l = 10))),
           tables.theme = theme_cleantable(),
           tables.height = 0.15,
           size = 1
) -> dis
dis$cumevents <- ove$cumevents;dis$cumevents$labels$x <- ""
dis$plot <- dis$plot + 
  theme(legend.position.inside = c(0.35,0.33),
        legend.key.size = unit(2.3, 'lines')) 

dis 

# add time table

library(grid)
library(gridExtra)

timetbl <- tableGrob(round(deceased, 1))
timetbl$widths <- rep(unit(1/ncol(timetbl),"null"), ncol(timetbl))
timetbl$heights <- rep(unit(1/nrow(timetbl), "null"), nrow(timetbl))
timetbl$grobs[[1]][["gp"]] <- gpar(fontsize=20, fontface="bold")
timetbl$grobs[[2]][["gp"]] <- gpar(fontsize=20, fontface="bold")
timetbl$grobs[[3]][["gp"]] <- gpar(fontsize=20, fontface="bold")
timetbl$grobs[[4]][["gp"]] <- gpar(fontsize=20, fontface="bold")
for (i in c(9:40)) {
  timetbl$grobs[[i]][["gp"]] <- gpar(fontsize = 20, fontface = "plain")
}
grid.newpage()
grid.draw(timetbl)

dis$plot <- dis$plot +
  annotation_custom(timetbl, xmin=12.2, xmax=26.9, ymin=0.06, ymax=0.57)
dis # png size 1160 690

png("Fig3.jpeg",width=12000,height=7000,res=600)
print(dis)
dev.off()

# discarded
fit.discarded <- survfit(Surv(days.discarded/365.25,Discarded) ~ 1, data = cryoadf)
ggsurvplot(fit.discarded, cryoadf, fun="event",
           break.time.by = 3, 
           cumevents = TRUE,
           fontsize = 8, # cumevents table number size
           conf.int = FALSE,
           palette = "white",
           xlab = "Time (years)",
           xlim = c(0,30),
           font.main = c(16, "bold", "black"),
           legend = "none",
           legend.title = "All",
           tables.height = 0.2,
           ggtheme = theme_light(),
           tables.theme = theme_cleantable() + 
             theme(text = element_text(size = 20, face = "bold"), # table title font size
                   axis.text.y = element_text(size = 20, face = "bold", # table strata name font size
                                              margin = margin(t=0,r=0,b=0,l=10)),
                   axis.title.y = element_blank(),
                   axis.ticks.x = element_blank(),
                   axis.text.x = element_blank()),
           size = 1
) -> ove
fit.discarded.dis <- survfit(Surv(days.discarded/365.25,Discarded) ~ Disease, data = cryoadf)
ggsurvplot(fit.discarded.dis, cryoadf, fun="event",
           title = "Time to Discarded: by Disease",
           break.time.by = 3, 
           cumevents = TRUE,
           pval = TRUE,
           pval.coord = c(15,0.7),
           pval.size = 10,
           xlab = "Time (years)",
           xlim = c(0,31),
           font.main = c(25, "bold", "black"), # title font
           font.tickslab = c(18, "plain", "black"), # x- y-lab, table number font size
           surv.median.line = "hv",
           legend = c(0.4,0.35),
           legend.title = "Time to outcomes",
           legend.labs = c("Testis cancer","Lymphoma","Leukemia","Sarcoma",
                           "Colorectal cancer","Brain cancer","Other cancer","Non cancer"),
           ggtheme = theme_light() +
             theme(legend.title = element_text(size = 20, color = "black", face = "bold"),
                   legend.text = element_text(size = 19, color = "black", face = "plain"),
                   axis.text.x = element_text(size = 20, color = "black", face = "bold"),
                   axis.text.y = element_text(size = 20, color = "black", face = "bold"),
                   axis.title.x = element_text(size = 20, color = "black", face = "bold"),
                   axis.title.y = element_text(size = 20, color = "black", face = "bold",
                                               margin = margin(t = 0, r = 10, b = 0, l = 10))),
           tables.theme = theme_cleantable(),
           tables.height = 0.15,
           size = 1
) -> dis
dis$cumevents <- ove$cumevents;dis$cumevents$labels$x <- ""
dis$plot <- dis$plot + 
  theme(legend.position.inside = c(0.41,0.33),
        legend.key.size = unit(2.3, 'lines'))
dis

# add time table


library(grid)
library(gridExtra)

timetbl <- tableGrob(round(discarded, 1))
timetbl$widths <- rep(unit(1/ncol(timetbl),"null"), ncol(timetbl))
timetbl$heights <- rep(unit(1/nrow(timetbl), "null"), nrow(timetbl))
timetbl$grobs[[1]][["gp"]] <- gpar(fontsize=20, fontface="bold")
timetbl$grobs[[2]][["gp"]] <- gpar(fontsize=20, fontface="bold")
timetbl$grobs[[3]][["gp"]] <- gpar(fontsize=20, fontface="bold")
timetbl$grobs[[4]][["gp"]] <- gpar(fontsize=20, fontface="bold")
for (i in c(9:40)) {
  timetbl$grobs[[i]][["gp"]] <- gpar(fontsize = 20, fontface = "plain")
}
grid.newpage()
grid.draw(timetbl)

dis$plot <- dis$plot +
  annotation_custom(timetbl, xmin=14.9, xmax=31.9, ymin=0.06, ymax=0.58)
dis # png size 1230 790

png("Fig4.jpeg",width=12000,height=7000,res=600)
print(dis)
dev.off()

# --------------------------
